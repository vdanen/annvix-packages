/* Public domain. */

#include <errno.h>
#include "bytestr.h"
#include "error.h"
#include "dns_helper.h"

unsigned int dns_packet_copy (char const *buf, unsigned int len, unsigned int pos, char *out, unsigned int outlen)
{
  if ((pos + outlen) > len) return (errno = EPROTO, 0) ;
  byte_copy(out, outlen, buf + pos) ;
  return pos + outlen ;
}

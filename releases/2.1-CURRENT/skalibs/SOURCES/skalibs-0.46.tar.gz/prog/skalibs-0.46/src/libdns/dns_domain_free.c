/* Public domain. */

#undef USE_DJBALLOC
#include "alloc.h"
#include "dns_helper.h"

void dns_domain_free (char **out)
{
  if (*out)
  {
    alloc_free(*out) ;
    *out = 0 ;
  }
}

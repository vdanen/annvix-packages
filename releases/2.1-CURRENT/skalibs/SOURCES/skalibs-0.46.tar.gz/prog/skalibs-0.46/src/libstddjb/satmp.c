/* Public domain. */

#include "gen_alloc.h"
#include "stralloc.h"
#include "skamisc.h"

stralloc satmp = GEN_ALLOC_ZERO ;

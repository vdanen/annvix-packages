ld="`head -n 1 conf-ld`"
strip="`head -n 1 conf-stripbins`"
test -n "$strip" || strip="echo Not stripping"
cat warn-auto.sh
echo 'main="$1"; shift ; ' "$ld" '-o "$main" "$main".o ${1+"$@"} ; exec ' "$strip" ' "$main"'

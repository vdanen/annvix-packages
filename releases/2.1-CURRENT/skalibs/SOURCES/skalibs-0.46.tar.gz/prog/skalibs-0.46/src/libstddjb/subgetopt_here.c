/* Public domain. */

/* MT-unsafe */

#include "sgetopt.h"

struct subgetopt_t subgetopt_here = SUBGETOPT_ZERO ;

#ifndef ENVIRON_H
#define ENVIRON_H

extern char const *const *environ ;

#endif

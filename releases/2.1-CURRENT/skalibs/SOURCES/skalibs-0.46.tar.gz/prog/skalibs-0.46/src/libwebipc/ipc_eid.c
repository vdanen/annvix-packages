/* Public domain. */

#include "getpeereid.h"
#include "webipc.h"

int ipc_eid (int s, int *u, int *g)
{
  int dummyu, dummyg ;
  if (getpeereid(s, &dummyu, &dummyg) == -1) return -1 ;
  *u = dummyu ;
  *g = dummyg ;
  return 0 ;
}

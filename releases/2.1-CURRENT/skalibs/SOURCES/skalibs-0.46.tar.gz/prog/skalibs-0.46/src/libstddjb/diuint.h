/* Public domain. */

#ifndef DIUINT_H
#define DIUINT_H

typedef struct diuint diuint, *diuint_ref ;
struct diuint
{
  unsigned int left ;
  unsigned int right ;
} ;

#endif

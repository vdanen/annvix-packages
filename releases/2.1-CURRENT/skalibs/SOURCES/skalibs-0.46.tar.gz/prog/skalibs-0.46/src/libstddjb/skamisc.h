/* Public domain. */

#ifndef SKAMISC_H
#define SKAMISC_H
/* sucky name, eh ? */

#include "buffer.h"
#include "stralloc.h"

extern stralloc satmp ;

extern int skagetln (buffer_ref, stralloc *, int) ;
extern int skagetlnsep (buffer_ref, stralloc *, char const *, unsigned int) ;

extern int sauniquename (stralloc *) ;

#define skaoffsetof(n, s, field) do { s sofoftmp ; *(n) = (unsigned char *)&sofoftmp->field - (unsigned char *)&sofoftmp ; } while (0)

#endif

/* Public domain. */

#undef USE_DJBALLOC
#include "uint64.h"
#include "gen_alloc.h"
#include "uint64alloc.h"

GEN_ALLOC_EXTENDED_DEFS(uint64alloc, uint64, s, len, a)

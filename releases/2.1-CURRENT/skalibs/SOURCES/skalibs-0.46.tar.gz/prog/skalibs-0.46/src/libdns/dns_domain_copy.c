/* Public domain. */

#include "bytestr.h"
#undef USE_DJBALLOC
#include "alloc.h"
#include "dns_helper.h"

int dns_domain_copy (char **out, char const *in)
{
  unsigned int len = dns_domain_length(in) ;
  char *x = alloc(len) ;
  if (!x) return 0 ;
  byte_copy(x, len, in) ;
  if (*out) alloc_free(*out) ;
  *out = x ;
  return 1 ;
}

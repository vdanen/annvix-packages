/* Public domain. */

/* MT-unsafe */

#include "bytestr.h"
#include "random.h"
#include "dns_helper.h"

/* XXX: sort servers by configurable notion of closeness? */
/* XXX: pay attention to competence of each server? */

void dns_sortip (char *s, unsigned int n)
{
  n >>= 2 ;
  while (n > 1)
  {
    char tmp[4] ;
    register unsigned int i = badrandom_int(n--) ;
    byte_copy(tmp, 4, s + (i << 2)) ;
    byte_copy(s + (i << 2), 4, s + (n << 2)) ;
    byte_copy(s + (n << 2), 4, tmp) ;
  }
}

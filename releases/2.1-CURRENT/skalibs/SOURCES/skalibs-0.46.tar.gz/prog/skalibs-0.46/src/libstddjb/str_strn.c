/* Public domain. */

#include "bytestr.h"

/* Very naive implementation, but it's small. */

unsigned int str_strn (char const *haystack, unsigned int hlen, char const *needle, unsigned int nlen)
{
  register unsigned int i = 0 ;
  if (!nlen) return 0 ;
  if (hlen < nlen) return hlen+1 ;
  hlen -= nlen ;
  for (; i < hlen ; i++)
    if (!str_diffn(haystack+i, needle, nlen)) return i ;
  return hlen+nlen+1 ;
}

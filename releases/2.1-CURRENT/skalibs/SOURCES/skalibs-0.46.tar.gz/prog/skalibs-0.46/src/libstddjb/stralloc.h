/* Public domain. */

#ifndef STRALLOC_H
#define STRALLOC_H

#include "gccattributes.h"
#include "gen_alloc.h"

GEN_ALLOC_PROTOTYPES(stralloc, char, s, len, a)

#define stralloc_shrink(sa) stralloc_clean(sa)
extern int stralloc_copys (stralloc *, char const *) ;
extern int stralloc_cats (stralloc *, char const *) ;
extern int stralloc_starts (stralloc *, char const *) gccattr_pure ;

extern int stralloc_insertb (stralloc *, unsigned int, char const *, unsigned int) ;
extern int stralloc_inserts (stralloc *, unsigned int, char const *) ;
extern int stralloc_insert (stralloc *, unsigned int, stralloc const *) ;

#define stralloc_0(sa) stralloc_catb(sa, "", 1)

#endif

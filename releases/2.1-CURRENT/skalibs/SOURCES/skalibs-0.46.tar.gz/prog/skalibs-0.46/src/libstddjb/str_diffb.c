/* Public domain. */

#include "bytestr.h"

int str_diffb (register char const *s, register unsigned int n, register char const *t)
{
  return str_diffn(s, t, n) ;
}

/* Public domain. */

/* MT-unsafe */

#include "buffer.h"

static char buf[BUFFER_OUTSIZE] ;
static buffer b = BUFFER_INIT(&buffer_unixwrite, 1, buf, BUFFER_OUTSIZE) ;
buffer_ref buffer_1 = &b ;

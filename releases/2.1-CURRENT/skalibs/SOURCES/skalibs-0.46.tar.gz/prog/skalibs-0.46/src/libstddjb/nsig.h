/* Public domain. */

#ifndef NSIG
# define NSIG 64
#endif

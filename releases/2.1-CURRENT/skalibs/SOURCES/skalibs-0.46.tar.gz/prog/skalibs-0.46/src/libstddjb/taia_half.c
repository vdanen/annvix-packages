/* Public domain. */

#include "tai.h"

void taia_half (struct taia *t, struct taia const *u)
{
  t->atto = u->atto>>1 ;
  if (u->nano & 1) t->atto += 500000000UL ;
  t->nano = u->nano>>1 ;
  if (tai_sec(&u->sec) & 1) t->nano += 500000000UL ;
  tai_u64(&t->sec, tai_sec(&u->sec)>>1) ;
}

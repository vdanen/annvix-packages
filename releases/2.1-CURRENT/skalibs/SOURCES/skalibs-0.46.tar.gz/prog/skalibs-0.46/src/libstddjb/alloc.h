/* Public domain. */

#ifndef ALLOC_H
#define ALLOC_H

#include "gccattributes.h"

typedef char aligned_char gccattr_aligned ;
typedef aligned_char *aligned_char_ref, **aligned_char_ref_ref ;

#ifdef USE_DJBALLOC
#define alloc djb_alloc
#define alloc_free djb_alloc_free
#define alloc_re djb_alloc_re
#define alloc_realloc djb_alloc_realloc
#else
#define alloc ska_alloc
#define alloc_free ska_alloc_free
#define alloc_re ska_alloc_re
#define alloc_realloc ska_alloc_realloc
#endif

extern aligned_char_ref alloc (unsigned int) gccattr_malloc ;
extern void alloc_free (void *) ;
extern int alloc_re (void **, unsigned int, unsigned int) ;
extern int alloc_realloc (void **, unsigned int) ;

#endif

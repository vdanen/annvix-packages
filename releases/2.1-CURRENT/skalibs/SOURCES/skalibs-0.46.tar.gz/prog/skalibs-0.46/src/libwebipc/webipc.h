/* Public domain. */

#ifndef WEBIPC_H
#define WEBIPC_H

#define IPCPATH_MAX 99

extern int ipc_stream (void) ;
extern int ipc_datagram (void) ;

extern int ipc_connect (int, char const *) ;
extern int ipc_bind (int, char const *) ;
extern int ipc_bind_reuse (int, char const *) ;
extern int ipc_listen (int, int) ;
extern int ipc_accept (int, char *, unsigned int, int *) ;
extern int ipc_eid (int, int *, int *) ;
extern int ipc_local (int, char *, unsigned int, int *) ;

#endif

/* Public domain. */

#include "uint32alloc.h"
#include "uint32aalloc.h"

GEN_ALLOC_BASE_DEFS(uint32aalloc, uint32alloc, s, len, a, 8)

void uint32aalloc_zerolen (uint32aalloc *z)
{
  while (z->len--) uint32alloc_free(z->s + z->len) ;
  z->len = 0 ;
}

void uint32aalloc_deepfree (uint32aalloc *z)
{
  uint32aalloc_zerolen(z) ;
  uint32aalloc_free(z) ;
}

/* Public domain. */

#include "tai.h"

void taia_sub (struct taia *t, struct taia const *u, struct taia const *v)
{
  unsigned long unano = u->nano ;
  unsigned long uatto = u->atto ;
  
  tai_sub(&t->sec, &u->sec, &v->sec) ;
  t->nano = unano - v->nano ;
  t->atto = uatto - v->atto ;
  if (t->atto > uatto)
  {
    t->atto += 1000000000UL ;
    --t->nano ;
  }
  if (t->nano > unano)
  {
    t->nano += 1000000000UL ;
    tai_u64(&t->sec, tai_sec(&t->sec)-1) ;
  }
}

/* Public domain. */

#include "uintalloc.h"
#include "gen_bunch.h"
#include "uintbunch.h"

GEN_BUNCH_DEFS(uintbunch, uintalloc, uint, 64, 16)

/* Public domain. */

#include "envalloc.h"

int envalloc_0 (envalloc *v)
{
  char const *z = 0 ;
  return envalloc_catb(v, &z, 1) ;
}

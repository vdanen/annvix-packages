/* Public domain. */

/* MT-unsafe */

#include "tai.h"
#include "caltimedate.h"
#include "leapsecs_internal.h"

struct tai *leapsecs ;
unsigned int leapsecs_num ;

int leapsecs_read ()
{
  int n = leapsecs_read_r(&leapsecs) ;
  if (n < 0) return n ;
  leapsecs_num = (unsigned int)n ;
  return 0 ;
}

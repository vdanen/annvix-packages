/* Public domain. */

/* MT-unsafe functions only. Use rrandom for MT-safety. */

#ifndef RANDOM_H
#define RANDOM_H

#include "stralloc.h"
#include "rrandom.h"

extern int badrandom_init (void) ;
extern unsigned char badrandom_char (void) ;
extern unsigned int badrandom_int (unsigned int) ;
extern int badrandom_string (char *, unsigned int) ;
extern void badrandom_finish (void) ;

extern int goodrandom_init (void) ;
extern unsigned char goodrandom_char (void) ;
extern unsigned int goodrandom_int (unsigned int) ;
extern int goodrandom_string (char *, unsigned int) ;
extern void goodrandom_finish (void) ;

extern void dns_random_init (char const *) ; /* 128 chars */
extern void dns_random_string (char *, unsigned int) ;
extern unsigned dns_random (unsigned int) ;

#define random_init badrandom_init
#define random_char badrandom_char
#define random_int badrandom_int
#define random_string badrandom_string
#define random_finish badrandom_finish

extern int random_name (char *, unsigned int) ;
extern int random_sauniquename (stralloc *, unsigned int) ;

#endif

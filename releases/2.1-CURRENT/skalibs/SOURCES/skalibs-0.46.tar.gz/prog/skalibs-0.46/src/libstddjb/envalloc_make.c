#include "bytestr.h"
#include "envalloc.h"

int envalloc_make (envalloc *v, unsigned int argc, char const *s, unsigned int len)
{
  register unsigned int pos = 0 ;
  if (!envalloc_ready(v, argc+1)) return 0 ;
  for (v->len = 0 ; v->len < argc ; v->len++)
  {
    v->s[v->len] = s + pos ;
    pos += str_len(s + pos) + 1 ;
  }
  (void)len ;
  return 1 ;
}

/* Public domain. */

#include "dns_helper.h"

int dns_domain_suffix (char const *big, char const *little)
{
  for (;;)
  {
    unsigned char c ;
    if (dns_domain_equal(big, little)) return 1 ;
    c = *big++ ;
    if (!c) return 0 ;
    big += c ;
  }
}

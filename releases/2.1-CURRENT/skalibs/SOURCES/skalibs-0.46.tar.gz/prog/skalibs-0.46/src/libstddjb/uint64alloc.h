/* Public domain. */

#ifndef UINT64ALLOC_H
#define UINT64ALLOC_H

#include "uint64.h"
#include "gen_alloc.h"

GEN_ALLOC_PROTOTYPES(uint64alloc, uint64, s, len, a)

#endif

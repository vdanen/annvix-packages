/* Public domain. */

#include <limits.h>
#include "fmtscan.h"
#include "fmtscan-internal.h"

SCANU(ulong, unsigned long, ULONG_MAX)

/* Public domain. */

#include "gen_alloc.h"
#include "diuint32.h"
#include "diuint32alloc.h"

GEN_ALLOC_BASE_DEFS(diuint32alloc, diuint32, s, len, a, 64)

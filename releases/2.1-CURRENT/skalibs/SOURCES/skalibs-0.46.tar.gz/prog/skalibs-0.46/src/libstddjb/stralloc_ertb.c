/* Public domain. */

#include "bytestr.h"
#include "stralloc.h"

int stralloc_insertb (stralloc *to, unsigned int offset, char const *s, unsigned int n)
{
  if (!stralloc_readyplus(to, n)) return 0 ;
  byte_copyr(to->s + offset + n, to->len - offset, to->s + offset) ;
  to->len += n ;
  byte_copyr(to->s + offset, n, s) ;
  return 1 ;
}

/* Public domain. */

#ifndef ENVALLOC_H
#define ENVALLOC_H

#include "gen_alloc.h"

GEN_ALLOC_PROTOTYPES(envalloc, char const *, s, len, a)

extern int envalloc_make (envalloc *, unsigned int, char const *, unsigned int) ;
extern int envalloc_uniq (envalloc *, char) ;
extern int envalloc_merge (envalloc *, char const *const *, unsigned int, char const *, unsigned int) ;
extern int envalloc_0 (envalloc *) ;

#endif

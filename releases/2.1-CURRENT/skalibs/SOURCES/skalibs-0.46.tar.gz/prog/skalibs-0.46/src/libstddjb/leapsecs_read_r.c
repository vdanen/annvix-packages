/* Public domain. */

#include "tai.h"
#include "caltimedate.h"

int leapsecs_read_r (struct tai **leapsecs)
{
  return leapsecs_readf_r("/etc/leapsecs.dat", leapsecs) ;
}

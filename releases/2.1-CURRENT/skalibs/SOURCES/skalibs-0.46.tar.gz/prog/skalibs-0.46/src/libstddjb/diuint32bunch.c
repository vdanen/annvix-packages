/* Public domain. */

#include "diuint32.h"
#include "diuint32alloc.h"
#include "gen_bunch.h"
#include "diuint32bunch.h"

GEN_BUNCH_DEFS(diuint32bunch, diuint32alloc, diuint32, 64, 16)

/* Public domain. */

#undef USE_DJBALLOC
#include "gen_alloc.h"
#include "intalloc.h"

GEN_ALLOC_BASE_DEFS(intalloc, int, s, len, a, 256)

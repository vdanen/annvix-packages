/* Public domain. */

#ifndef ENV_H
#define ENV_H

#include "gccattributes.h"
#include "stralloc.h"

extern unsigned int env_len (char const *const *) gccattr_pure ;
extern char const *env_get (char const *) gccattr_pure ;
extern char const *env_get2 (char const *const *, char const *) gccattr_pure ;
extern char const *ucspi_get (char const *) gccattr_pure ;
extern char const *ucspi_get_tmp (char const *, stralloc *) gccattr_pure ;
extern int env_addmodif (stralloc *, char const *, char const *) ;
extern int env_string (stralloc *, char const *const *, unsigned int) ;

#endif

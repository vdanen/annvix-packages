/* Public domain. */

#include "tai.h"
#include "stralloc.h"
#include "dns_transmit.h"

void dns_rcrw_info_free (struct dns_rcrw_info *d)
{
  struct taia zero = TAIA_ZERO ;
  d->uses = 0 ;
  d->deadline = zero ;
  stralloc_free(&d->rules) ;
}

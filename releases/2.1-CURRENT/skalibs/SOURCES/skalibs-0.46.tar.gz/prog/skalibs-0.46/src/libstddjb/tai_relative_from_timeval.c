/* Public domain. */

#include <sys/time.h>
#include <errno.h>
#include "tai.h"

int tai_relative_from_timeval (struct tai *t, struct timeval const *tv)
{
  if ((tv->tv_sec < 0) || (tv->tv_usec < 0)) return (errno = EINVAL, 0) ;
  tai_uint(t, tv->tv_sec) ;
  return 1 ;
}

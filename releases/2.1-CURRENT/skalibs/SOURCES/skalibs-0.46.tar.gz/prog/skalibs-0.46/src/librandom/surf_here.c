/* Public domain. */

/* MT-unsafe */

#include "surf.h"
#include "random-internal.h"

SURFSchedule surf_here = SURFSCHEDULE_ZERO ;

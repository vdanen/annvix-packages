/* Public domain. */

/* MT-unsafe */

#include "stralloc.h"
#include "dns_transmit.h"

int dns_ip4_qualify (stralloc *out, stralloc *fqdn, stralloc const *in)
{
  return dns_ip4_qualifyb(out, fqdn, in->s, in->len) ;
}

/* Public domain. */

#ifndef SELFPIPE_H
#define SELFPIPE_H

extern int selfpipe_init (void) ; /* returns -1 or fd to select on */
extern int selfpipe_trap (int) ;
extern int selfpipe_read (void) ;
extern void selfpipe_finish (void) ;

#endif

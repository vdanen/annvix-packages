/* Public domain. */

#include "fmtscan.h"

unsigned int long_scan (char const *s, long *n)
{
  if ((*s == '-') || (*s == '+'))
  {
    unsigned long tmp ;
    register unsigned int r = ulong_scan(s+1, &tmp) ;
    if (!r) return 0 ;
    *n = (*s == '-') ? -tmp : tmp ;
    return r + 1 ;
  }
  return ulong_scan(s, (unsigned long *)n) ;
}

# Version number and release date.
VERSION_NUMBER=0.16
RELEASE_DATE=2006-10-26      # in "date +%Y-%m-%d" format

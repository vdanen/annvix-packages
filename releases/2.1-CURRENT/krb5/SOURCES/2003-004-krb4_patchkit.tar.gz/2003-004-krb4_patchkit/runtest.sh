
#!/bin/sh
set -e
start_kdc() {
    if [ -r kdc.log ]; then
	cat kdc.log >>kdc.log.full
	rm kdc.log
	fi
    build/kdc/krb5kdc -n $@&
    kdc_pid=$!
    build/krb524/krb524d -nofork -m  $@&
krb524_pid=$!
}

stop_kdc() {
    kill $kdc_pid
    kill $krb524_pid
    }

newtest() {
echo  Testing $1:  \\c >&3
}
pass() {
echo OK >&3
}

 PATH=build/clients/kinit:build/clients/kvno:$PATH; export PATH
exec 3>&1
exec 2>test.log >&2


    
 KRB5_CONFIG=./krb5.conf
 KRB5_KDC_PROFILE=./kdc.conf
KRB5CCNAME=/tmp/krb5cc_testing
KRBTKFILE=/tmp/tkt_testing
export KRB5_CONFIG KRB5_KDC_PROFILE KRB5CCNAME KRBTKFILE

start_kdc
sleep 3
newtest "1A"

echo passwordgoeshere |./kinit -4 v4test@PREPATCH.KRBTEST.COM
(./kvno -4 service@PATCH ||true) 2>&1 |grep -i unknown
grep denied kdc.log
pass
newtest "1B"
echo passwordgoeshere |kinit -5 v4test@PREPATCH.KRBTEST.COM
(/mit/krb5/bin/krb524init -p service@PATCH ||true) 2>&1 |grep -i policy
klist -5 |grep  service@PATCH
pass
stop_kdc
start_kdc -X
newtest 2A
grep -i security kdc.log
pass
newtest 2B
echo passwordgoeshere |./kinit -4 v4test@PREPATCH.KRBTEST.COM
./kvno -4 service@PATCH
klist -4 |grep -i service@PATCH
pass
newtest 2C
echo passwordgoeshere |kinit -5 v4test@PREPATCH.KRBTEST.COM
/mit/krb5/bin/krb524init -p service@PATCH
pass
newtest 3
echo test |kinit -5 test@PATCH
stop_kdc
KRB5_CONFIG=krb5.conf.only-des
start_kdc
sleep 2
(kvno service@PATCH ||true) 2>&1 |grep -i generic
egrep -i permitted\|matching  kdc.log
pass
stop_kdc

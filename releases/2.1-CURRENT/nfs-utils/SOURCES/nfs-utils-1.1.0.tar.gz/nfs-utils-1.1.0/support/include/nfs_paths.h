#ifndef _NFS_PATHS_H
#define _NFS_PATHS_H

#ifndef _PATH_MOUNTED
#define _PATH_MOUNTED "/etc/fstab"
#endif
#define MOUNTED_LOCK	_PATH_MOUNTED "~"
#define MOUNTED_TEMP	_PATH_MOUNTED ".tmp"

#endif /* _NFS_PATHS_H */


/* Copyright 2005 Red Hat, Inc.
 *
 * This software may be freely redistributed under the terms of the GNU
 * public license.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 */

#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/fd.h>

#include "ps3.h"
#include "kudzuint.h"
#include "modules.h"

static void ps3FreeDevice(struct ps3Device *dev)
{
	freeDevice((struct device *) dev);
}

static void ps3WriteDevice(FILE *file, struct ps3Device *dev)
{
	writeDevice(file, (struct device *)dev);
}

static int ps3CompareDevice(struct ps3Device *dev1, struct ps3Device *dev2)
{
	return compareDevice( (struct device *)dev1, (struct device *)dev2);
}

struct ps3Device *ps3NewDevice(struct ps3Device *old)
{
	struct ps3Device *ret;

	ret = malloc(sizeof(struct ps3Device));
	memset(ret, '\0', sizeof(struct ps3Device));
	ret = (struct ps3Device *) newDevice((struct device *) old, (struct device *) ret);
	ret->bus = BUS_PS3;
	ret->newDevice = ps3NewDevice;
	ret->freeDevice = ps3FreeDevice;
	ret->writeDevice = ps3WriteDevice;
	ret->compareDevice = ps3CompareDevice;
	return ret;
}

struct device *ps3Probe(enum deviceClass probeClass, int probeFlags,
			struct device *devlist)
{
#ifdef __powerpc__
	struct ps3Device *ps3dev;

	if ((probeClass & CLASS_USB) ||
	    (probeClass & CLASS_NETWORK)) {
		DIR * dir;
		struct dirent * ent;

		if (access("/sys/bus/ps3_system_bus/devices", R_OK)) 
			return devlist;

		dir = opendir("/sys/bus/ps3_system_bus/devices");
		while ((ent = readdir(dir))) {
			char path[64];
			int fd;
			char alias[16];

			snprintf(path, 64, "/sys/bus/ps3_system_bus/devices/%s/modalias", ent->d_name);

			fd = open(path, O_RDONLY);
			if (fd < 0)
				continue;
			memset(alias, 0, 16);
			if (read(fd, alias, 15) <= 0) {
				close(fd);
				continue;
			}
			close(fd);
			if (strncmp(alias, "ps3:", 4))
				continue;
			if (alias[5] != '\n')
				continue;
			alias[5] = 0;
			if (probeClass & CLASS_USB && alias[4] == '1') {
				ps3dev = ps3NewDevice(NULL);
				ps3dev->type = CLASS_USB;
				ps3dev->desc = strdup("PlayStation 3 EHCI");
				ps3dev->driver = strdup("ehci-hcd");
			} else if (probeClass & CLASS_USB && alias[4] == '2') {
				ps3dev = ps3NewDevice(NULL);
				ps3dev->type = CLASS_USB;
				ps3dev->desc = strdup("PlayStation 3 OHCI");
				ps3dev->driver = strdup("ohci-hcd");
			} else if (probeClass & CLASS_NETWORK && alias[4] == '3') {
				ps3dev = ps3NewDevice(NULL);
				ps3dev->type = CLASS_NETWORK;
				ps3dev->desc = strdup("PlayStation 3 Gigabit Ethernet");
				ps3dev->driver = strdup("gelic_net");
				__getSysfsDevice((struct device *)ps3dev, path, "net:",0);
				if (ps3dev->device)
					__getNetworkAddr((struct device *)ps3dev, ps3dev->device);
				else
					ps3dev->device = strdup("eth");
			} else
				continue;		    

			if (!ps3dev->driver)
				ps3dev->driver = strdup(alias);
			if (devlist)
				ps3dev->next = devlist;
			devlist = (struct device *) ps3dev;
		}
		closedir(dir);
	}

	if (probeClass & CLASS_VIDEO) {
		char path[64];
		int i;
		char *name;

		for (i = 0; ; i++) {
			snprintf(path,64,"/sys/class/graphics/fb%d/name",i);
			name = __readString(path);
			if (!name)
				break;
			if (!strcmp(name, "PS3 FB")) {
				ps3dev = ps3NewDevice(NULL);
				ps3dev->desc = strdup("PlayStation 3 Framebuffer");
				ps3dev->type = CLASS_VIDEO;
				ps3dev->driver = strdup("ps3fb");
				ps3dev->classprivate = (void *)strdup("fbdev");
				if (devlist)
					ps3dev->next = devlist;
				devlist = (struct device *) ps3dev;
			}
		}
	}

	if (probeClass & CLASS_SCSI) {
		char model[16];
		int fd = open("/proc/device-tree/model", O_RDONLY);
		if (fd >= 0) {
			if (read(fd, model, 16) == 14 && !strncmp(model, "PLAYSTATION 3", 13)) {
				ps3dev = ps3NewDevice(NULL);
				ps3dev->desc = strdup("PlayStation 3 storage");
				ps3dev->driver = strdup("ps3_storage");
				ps3dev->type = CLASS_SCSI;
				if (devlist)
					ps3dev->next = devlist;
				devlist = (struct device *) ps3dev;
			}
			close(fd);
		}
	}
#endif
	return devlist;
}

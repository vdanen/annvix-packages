/* Copyright 2004 Red Hat, Inc.
 *
 * This software may be freely redistributed under the terms of the GNU
 * public license.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 */

#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/fd.h>

#include "vio.h"
#include "kudzuint.h"
#include "modules.h"

static void vioFreeDevice(struct vioDevice *dev)
{
	freeDevice((struct device *) dev);
}

static void vioWriteDevice(FILE *file, struct vioDevice *dev)
{
	writeDevice(file, (struct device *)dev);
}

static int vioCompareDevice(struct vioDevice *dev1, struct vioDevice *dev2)
{
	return compareDevice( (struct device *)dev1, (struct device *)dev2);
}

struct vioDevice *vioNewDevice(struct vioDevice *old)
{
	struct vioDevice *ret;

	ret = malloc(sizeof(struct vioDevice));
	memset(ret, '\0', sizeof(struct vioDevice));
	ret = (struct vioDevice *) newDevice((struct device *) old, (struct device *) ret);
	ret->bus = BUS_VIO;
	ret->newDevice = vioNewDevice;
	ret->freeDevice = vioFreeDevice;
	ret->writeDevice = vioWriteDevice;
	ret->compareDevice = vioCompareDevice;
	return ret;
}

struct device *vioProbe(enum deviceClass probeClass, int probeFlags,
			struct device *devlist)
{
#ifdef __powerpc__
	struct vioDevice *viodev;
	int isIseries = !access("/proc/iSeries", F_OK);
	
	if (probeClass & CLASS_HD) {
		if (!access("/proc/device-tree/mambo", R_OK)) {
			DIR * dir;
			struct dirent * ent;
			int ctlNum;
			
			dir = opendir("/proc/device-tree/mambo");
			while ((ent = readdir(dir))) {
				if (strncmp("bogus-disc@", ent->d_name, 11))
					continue;
				ctlNum = atoi(ent->d_name + 11);
				viodev = vioNewDevice(NULL);
				viodev->device = malloc(20);
				snprintf(viodev->device, 19, "mambobd%d", ctlNum);
				viodev->desc = strdup("IBM Mambo virtual disk");
				viodev->type = CLASS_HD;
				viodev->driver = strdup("mambo_bd");
				if (devlist)
					viodev->next = devlist;
				devlist = (struct device *) viodev;
			}
		}
	} 
	if (probeClass & CLASS_NETWORK) {
		if (!access("/proc/device-tree/mambo/bogus-net@0", R_OK)) {
			viodev = vioNewDevice(NULL);
			viodev->device = strdup("eth");
			viodev->desc = strdup("Mambo Virtual Ethernet");
			viodev->type = CLASS_NETWORK;
			viodev->driver = strdup("mambonet");
			if (devlist)
				viodev->next = devlist;
			devlist = (struct device *) viodev;
		}
	} 
	
	if (probeClass & CLASS_NETWORK ||
	    probeClass & CLASS_HD ||
	    probeClass & CLASS_CDROM ||
	    probeClass & CLASS_SCSI) {
		DIR *dir;
		struct dirent *ent;
	    
		if (probeClass & CLASS_SCSI && isIseries) {
			viodev = vioNewDevice(NULL);
			viodev->desc = strdup("IBM Virtual DASD");
			viodev->driver = strdup("viodasd");
			viodev->type = CLASS_SCSI;
			if (devlist)
				viodev->next = devlist;
			devlist = (struct device *) viodev;
		}
		dir = opendir("/sys/bus/vio/devices");
		while ((ent = readdir(dir))) {
			char *path;
			char *devspec;
		    
			if (ent->d_name[0] == '.' || !strcmp(ent->d_name,"vio"))
				continue;
			if (asprintf(&path,"/sys/bus/vio/devices/%s/devspec",ent->d_name) == -1)
				continue;
                        devspec = __readString(path);
			if (probeClass & CLASS_NETWORK &&
			    !strncmp(devspec,"/vdevice/l-lan",14)) {
				viodev = vioNewDevice(NULL);
				__getSysfsDevice((struct device *)viodev, dirname(path), "net:", 0);
				if (!viodev->device) {
					vioFreeDevice(viodev);
					continue;
				}
				__getNetworkAddr((struct device *)viodev, viodev->device);
				viodev->desc = strdup("IBM Virtual Ethernet");
				viodev->driver = isIseries ? strdup("iseries_veth") : strdup("ibmveth");
				viodev->type = CLASS_NETWORK;
				if (devlist)
					viodev->next = devlist;
				devlist = (struct device *)viodev;
			}
			if (probeClass & CLASS_HD &&
			    !strncmp(devspec,"/vdevice/viodasd",16)) {
				viodev = vioNewDevice(NULL);
				__getSysfsDevice((struct device *)viodev, dirname(path), "block:", 0);
				if (!viodev->device) {
					vioFreeDevice(viodev);
					continue;
				}
				viodev->desc = strdup("IBM Virtual DASD");
				viodev->type = CLASS_HD;
				if (devlist)
					viodev->next = devlist;
				devlist = (struct device *)viodev;
			}
			if (probeClass & CLASS_CDROM &&
			    !strncmp(devspec,"/vdevice/viocd", 14)) {
				viodev = vioNewDevice(NULL);
				__getSysfsDevice((struct device *)viodev, dirname(path), "block:", 0);
				if (!viodev->device) {
					vioFreeDevice(viodev);
					continue;
				}
				viodev->desc = strdup("IBM Virtual CD-ROM");
				viodev->type = CLASS_CDROM;
				if (devlist)
					viodev->next = devlist;
				devlist = (struct device *)viodev;
			}
			if (probeClass & CLASS_SCSI && !isIseries &&
			    !strncmp(devspec,"/vdevice/v-scsi",15)) {
				viodev = vioNewDevice(NULL);
				viodev->desc = strdup("IBM Virtual SCSI");
				viodev->driver = strdup("ibmvscsic");
				viodev->type = CLASS_SCSI;
				if (devlist)
					viodev->next = devlist;
					devlist = (struct device *) viodev;
			}
			free(path);
		}
	}
#endif
	return devlist;
}

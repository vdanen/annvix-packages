extern int high_water_alloc(void **buf, size_t *bufsize, size_t newsize);

extern const char *quote(const char *str);
extern char *unquote(char *str);

extern int high_water_alloc(void **buf, size_t *bufsize, size_t newsize);

extern const char *quote(const char *str);
extern char *unquote(char *str);

extern char *next_line(FILE *file);

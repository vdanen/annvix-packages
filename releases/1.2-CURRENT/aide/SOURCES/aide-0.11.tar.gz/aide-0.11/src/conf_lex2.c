/* $Header: /cvsroot/aide/aide/src/conf_lex2.c,v 1.1 2005/04/06 09:50:26 rvdb Exp $
 * This file is needed because flex generates a C file
 * that includes <stdio.h> before "aide.h"
 */

#include "aide.h"
#include "conf_lex.c"

#!/usr/bin/perl

print "Content-type: text/plain\r\n\r\n";

print "\n\n";
print "----------------------------------------\n";
print "This is used by mod_security regression \n";
print "tests in order to verify that the module\n";
print "works as it is supposed to.\n";
print "----------------------------------------\n";
print "\n\n";

foreach $var (sort(keys(%ENV))) {
    $val = $ENV{$var};
    $val =~ s|\n|\\n|g;
    $val =~ s|"|\\"|g;
    print "${var}=\"${val}\"\n";
}

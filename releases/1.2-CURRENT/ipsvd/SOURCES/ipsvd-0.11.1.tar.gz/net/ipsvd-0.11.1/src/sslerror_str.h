#ifndef SSLERROR_STR_H
#define SSLERROR_STR_H

extern const char *sslerror_str(int);

#endif

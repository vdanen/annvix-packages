/* 
 * validate.h
 *
 * Header file for validate.c
 */ 

#ifndef __VALIDATE_H__
#define __VALIDATE_H__

/* The longest allowable length of a username */
#define MAX_USERNAME_LENGTH 100

/* The longest allowable length of the plaintext password*/
#define MAX_PW_LENGTH 100

/* How many seconds to sleep on a failed validation */
#define SLEEP_SECONDS (3)

/* Whether or not to record failed attempts in the system log defined=yes, not defined=no */
#define LOG_FAILED_ATTEMPTS 

#endif


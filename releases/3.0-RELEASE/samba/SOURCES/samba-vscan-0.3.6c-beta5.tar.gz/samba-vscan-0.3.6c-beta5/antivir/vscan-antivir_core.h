#ifndef __VSCAN_ANTIVIR_CORE_H_
#define __VSCAN_ANTIVIR_CORE_H_

#include "vscan-antivir.h"

#endif /* __VSCAN_ANTIVIR_CORE_H */

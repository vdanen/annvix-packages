#ifndef __VSCAN_MKSD_H_
#define __VSCAN_MKSD_H_

#include "vscan-global.h"

/* default location of samba-style configuration file (needs Samba >= 2.2.4
 or Samba 3.0 */

#define PARAMCONF "/etc/samba/vscan-mks32.conf"

/* End Configuration Section */


/* functions by vscan-mks_core */
/* opens a socket */
int vscan_mksd_init(void); 
/* scans a file */
int vscan_mksd_scanfile(int sockfd, const char *scan_file, const char* client_ip);
/* closes socket */
void vscan_mksd_end(int sockfd);


#endif /* __VSCAN_OAV_H_ */

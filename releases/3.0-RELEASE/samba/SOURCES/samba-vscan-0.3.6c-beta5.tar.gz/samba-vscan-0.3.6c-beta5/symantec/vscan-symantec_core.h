#ifndef __VSCAN_SYMANTEC_CORE_H_
#define __VSCAN_SYMANTEC_CORE_H_

#include "vscan-symantec.h"	

#include "symcsapi.h"


#endif /* __VSCAN_SYMANTEC_CORE_H */

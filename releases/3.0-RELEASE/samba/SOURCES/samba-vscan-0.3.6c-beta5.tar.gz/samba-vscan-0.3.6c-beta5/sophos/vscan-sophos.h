#ifndef __VSCAN_SOPHOS_H_
#define __VSCAN_SOPHOS_H_

#include "vscan-global.h"


/* Configuration Section :-) */

/* default location of samba-style configuration file (needs Samba >= 2.2.4
 or Samba 3.0 */

#define PARAMCONF "/etc/samba/vscan-sophos.conf"

/* Sophie stuff:
   socket name of Sophie daemon */
#define SOPHIE_SOCKET_NAME      "/var/run/sophie"

/* End Configuration Section */

/* functions by vscan-sophos_core */
/* opens socket */
int vscan_sophos_init(void); 
/* scans a file */
int vscan_sophos_scanfile(int sockfd, char *scan_file, char *client_ip);
/* terminates SAVI */
void vscan_sophos_end(int sockfd);


#endif /* __VSCAN_SOPHOS_H_ */

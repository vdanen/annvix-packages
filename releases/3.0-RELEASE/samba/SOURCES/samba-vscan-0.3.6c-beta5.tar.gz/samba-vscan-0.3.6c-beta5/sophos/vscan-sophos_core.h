#ifndef __VSCAN_SOPHOS_CORE_H_
#define __VSCAN_SOPHOS_CORE_H_

#include "vscan-sophos.h"	

#endif /* __VSCAN_SOPHOS_CORE_H */

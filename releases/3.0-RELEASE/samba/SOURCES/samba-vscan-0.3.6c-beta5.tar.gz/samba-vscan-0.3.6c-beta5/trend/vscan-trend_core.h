#ifndef __VSCAN_TREND_CORE_H_
#define __VSCAN_TREND_CORE_H_

#include "vscan-trend.h"	

#endif /* __VSCAN_TREND_CORE_H */

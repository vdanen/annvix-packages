#ifndef __VSCAN_TREND_H_
#define __VSCAN_TREND_H_

#include "vscan-global.h"


/* Configuration Section :-) */

/* default location of samba-style configuration file (needs Samba >= 2.2.4
 or Samba 3.0 */

#define PARAMCONF "/etc/samba/vscan-trend.conf"

/* Trophie stuff:
   socket name of Trophie daemon */
#define TROPHIE_SOCKET_NAME      "/var/run/trophie"

/* End Configuration Section */


/* functions by vscan-trend_core */
/* opens socket */
int vscan_trend_init(void); 
/* scans a file */
int vscan_trend_scanfile(int sockfd, char *scan_file, char *client_ip);
/* terminates SAVI */
void vscan_trend_end(int sockfd);


#endif /* __VSCAN_TREND_H_ */

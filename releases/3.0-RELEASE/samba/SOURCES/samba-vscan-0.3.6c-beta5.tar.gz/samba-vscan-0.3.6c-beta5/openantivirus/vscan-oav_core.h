#ifndef __VSCAN_OAV_CORE_H_
#define __VSCAN_OAV_CORE_H_

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "vscan-oav.h"

#endif /* __VSCAN_OAV_CORE_H */

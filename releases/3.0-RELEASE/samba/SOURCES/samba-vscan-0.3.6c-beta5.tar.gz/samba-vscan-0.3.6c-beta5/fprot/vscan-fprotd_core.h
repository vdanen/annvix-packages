#ifndef __VSCAN_FPROTD_CORE_H_
#define __VSCAN_FPROTD_CORE_H_

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "vscan-fprotd.h"

#endif /* __VSCAN_FPROTD_CORE_H */

#ifndef __VSCAN_ICAP_CORE_H_
#define __VSCAN_ICAP_CORE_H_

#include "vscan-icap.h"	


#endif /* __VSCAN_ICAP_CORE_H */

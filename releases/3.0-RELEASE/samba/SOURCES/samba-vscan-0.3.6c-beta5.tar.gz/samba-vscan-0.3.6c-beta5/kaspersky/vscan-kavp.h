#ifndef __VSCAN_KAVP_H_
#define __VSCAN_KAVP_H_

#include "vscan-global.h"

/* Configuration Section :-) */

/* default location of samba-style configuration file (needs Samba >= 2.2.4
 or Samba 3.0 */

#define PARAMCONF "/etc/samba/vscan-kavp.conf"

/* Daemon socket file */

#define AVPCTL "/var/run/AvpCtl"

/* End Configuration Section */

/* Globals */
int 	kavp_socket;			/* Remember our socket number  -1 is not socket */
int  vscan_kavp_scanfile(char *scan_file, char* client_ip);
void vscan_kavp_init(void);
void vscan_kavp_end(void);

#endif /* __VSCAN_KAVP_H */


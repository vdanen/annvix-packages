#ifndef __VSCAN_MCDAEMON_CORE_H_
#define __VSCAN_MCDAEMON_CORE_H_

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "vscan-mcdaemon.h"

#endif /* __VSCAN_MCDAEMON_CORE_H */

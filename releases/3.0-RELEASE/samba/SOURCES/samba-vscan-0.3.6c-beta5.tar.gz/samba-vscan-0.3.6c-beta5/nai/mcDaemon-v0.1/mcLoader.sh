#!/bin/sh
. /etc/sysconfig/MCDaemon
x=0;
export NUM_MCD=$NUM_MCD
while [ "$x" -le "$NUM_MCD" ]; do
/var/lib/mcdaemon/mcdaemon $x &
x=$(expr $x + 1)
done
/var/lib/mcdaemon/mcdaemon 0 &


#include "strerr2.h"
#include "djbunix.h"

char const *PROG = "exec" ;
#define USAGE "exec prog..."

 /* This is the most useful command ever. Really. */

int main (int argc, char const *const *argv, char const *const *envp)
{
  if (argc < 2) strerr_dieusage(100, USAGE) ;
  pathexec_run(argv[1], argv+1, envp) ;
  strerr_dieexec(111, argv[1]) ;
}

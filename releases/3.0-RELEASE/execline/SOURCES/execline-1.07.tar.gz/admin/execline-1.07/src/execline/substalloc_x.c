#include "gen_alloc.h"
#include "execline.h"
#include "exlp.h"

GEN_ALLOC_EXTENDED_DEFS(substalloc, elsubst, s, len, a)

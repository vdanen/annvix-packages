#include "exls1.h"

char const *PROG = "elglob" ;
#define USAGE "elglob [ -v ] [ -w ] [ -s ] [ -m ] [ -e ] [ -0 ] key pattern prog..."

int main (int argc, char const **argv, char const *const *envp)
{
  exls1_main(argc, argv, envp, &exls1_elglob, USAGE) ;
}

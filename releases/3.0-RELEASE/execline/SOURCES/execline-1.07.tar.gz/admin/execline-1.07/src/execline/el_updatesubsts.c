#include "execline.h"

void el_updatesubsts (elsubst *s, unsigned int len, char const *vars, char const *values, unsigned int *offsets)
{
  register unsigned int i = 0 ;
  for ( ; i < len ; i++)
  {
    s[i].var = vars + offsets[i<<1] ;
    s[i].value = values + offsets[(i<<1)+1] ;
  }
}

#include "bytestr.h"
#include "strerr2.h"
#include "djbunix.h"

char const *PROG = "export" ;
#define USAGE "export variable value prog..."

int main (int argc, char const *const *argv)
{
  if (argc < 4) strerr_dieusage(100, USAGE) ;
  if (argv[1][str_chr(argv[1], '=')])
    strerr_dief2x(100, "invalid variable name: ", argv[1]) ;
  if (!pathexec_env(argv[1], argv[2]))
    strerr_diefu4sys(111, "set ", argv[1], " to ", argv[2]) ;
  pathexec(argv+3) ;
  strerr_dieexec(111, argv[3]) ;
}

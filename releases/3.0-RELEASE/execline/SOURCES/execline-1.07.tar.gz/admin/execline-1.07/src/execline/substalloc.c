#include "gen_alloc.h"
#include "execline.h"
#include "exlp.h"

GEN_ALLOC_BASE_DEFS(substalloc, elsubst, s, len, a, 4)

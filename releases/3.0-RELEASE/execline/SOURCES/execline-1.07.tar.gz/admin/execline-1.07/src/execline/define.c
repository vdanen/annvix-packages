#include "exls1.h"

char const *PROG = "define" ;
#define USAGE "define [ -n ] [ -s ] [ -C | -c ] [ -d delim ] key value prog..."

int main (int argc, char const **argv, char const *const *envp)
{
  exls1_main(argc, argv, envp, &exls1_define, USAGE) ;
}

#ifndef EXLS1_H
#define EXLS1_H

#include "gccattributes.h"
#include "gen_alloc.h"
#include "stralloc.h"
#include "execline.h"

typedef struct exls1info exls1info, *exls1info_ref ;
struct exls1info
{
  char const *var ;
  stralloc value ;
  unsigned int n ;
} ;

#define EXLS1INFO_ZERO { 0, GEN_ALLOC_ZERO, 0 }

typedef int exls1_t (int, char const **, char const *const *, exls1info_ref) ;
typedef exls1_t *exls1_t_ref ;

extern exls1_t exls1_define ;
extern exls1_t exls1_importas ;
extern exls1_t exls1_import ;
extern exls1_t exls1_backtick ;
extern exls1_t exls1_elglob ;

extern int  exls1_doit (int, char const **, char const *const *, exls1_t_ref) ;
extern void exls1_main (int, char const **, char const *const *, exls1_t_ref, char const *) gccattr_noreturn ;

#endif

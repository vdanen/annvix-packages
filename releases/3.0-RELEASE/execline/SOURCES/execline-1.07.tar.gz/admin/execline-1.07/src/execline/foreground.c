#include "strerr2.h"
#include "execline.h"

char const *PROG = "foreground" ;

int main (int argc, char const **argv)
{
  int argc1 = el_semicolon(++argv) ;
  if (argc1 >= --argc) strerr_dief1x(100, "unterminated block") ;
  argv[argc1] = 0 ;
  el_execsequence(argv, argv+argc1+1) ;
}

#include "exls1.h"

char const *PROG = "backtick" ;
#define USAGE "backtick [ -i ] [ -n ] [ -s ] [ -C | -c ] [ -d delim ] key ~prog... ; remainder..."

int main (int argc, char const **argv, char const *const *envp)
{
  exls1_main(argc, argv, envp, &exls1_backtick, USAGE) ;
}

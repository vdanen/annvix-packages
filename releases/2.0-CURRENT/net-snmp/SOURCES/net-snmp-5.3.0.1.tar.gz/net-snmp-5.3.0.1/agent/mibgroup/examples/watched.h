#ifndef EXAMPLES_WATCHED_H
#define EXAMPLES_WATCHED_H

#ifdef __cplusplus
extern "C" {
#endif

void init_watched(void);

#ifdef __cplusplus
}
#endif

#endif /* EXAMPLES_WATCHED_H */

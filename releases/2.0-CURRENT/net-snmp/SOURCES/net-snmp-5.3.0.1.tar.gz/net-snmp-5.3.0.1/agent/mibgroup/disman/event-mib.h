config_warning(New version of the Event MIB which may be subtly different from the original implementation - configure with 'disman/old-event-mib' for the previous version)
config_require(disman/event)


/* $Id: sp_flowbits.h,v 1.1 2004/02/03 15:39:05 jh8 Exp $ */
/* flowbits detection plugin header */

#ifndef __SP_FLOWBITS_H__
#define __SP_FLOWBITS_H__

void SetupFlowBits();
void FlowBitsVerify();
#endif  /* __SP_FLOWBITS_H__ */

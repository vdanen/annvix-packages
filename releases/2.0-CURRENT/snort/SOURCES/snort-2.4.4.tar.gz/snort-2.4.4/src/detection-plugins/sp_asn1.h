#ifndef __SP_ASN1_H__
#define __SP_ASN1_H__

void SetupAsn1();

#endif

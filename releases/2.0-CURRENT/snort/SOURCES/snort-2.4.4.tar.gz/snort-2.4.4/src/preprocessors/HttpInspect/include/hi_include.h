#ifndef __HI_INCLUDE_H__
#define __HI_INCLUDE_H__

#ifndef INLINE

#ifdef WIN32
#define INLINE __inline
#else
#define INLINE inline
#endif

#endif /* endif for INLINE */

#endif

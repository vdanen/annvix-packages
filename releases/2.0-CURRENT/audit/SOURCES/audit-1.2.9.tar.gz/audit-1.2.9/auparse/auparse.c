/* auparse.c --
 * Copyright 2006 Red Hat Inc., Durham, North Carolina.
 * All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors:
 *      Steve Grubb <sgrubb@redhat.com>
 */

#include "config.h"
#include "internal.h"
#include "auparse.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


/* General functions that affect operation of the library */
auparse_state_t *auparse_init(ausource_t source, const void *b)
{
	char **tmp, **bb = (char **)b;
	int n, i;

	auparse_state_t *au = malloc(sizeof(auparse_state_t));
	if (au == NULL) {
		errno = ENOMEM;
		return NULL;
	}

	switch (source)
	{
		case AUSOURCE_LOGS:
			au->source_list = NULL;
			break;
		case AUSOURCE_FILE:
			tmp = malloc(2*sizeof(char *));
			tmp[0] = strdup(b);
			tmp[1] = NULL;
			au->source_list = tmp;
			break;
		case AUSOURCE_FILE_ARRAY:
			n = 0;
			while (bb[n])
				n++;
			tmp = malloc(n*sizeof(char *));
			for (i=0; i<n; i++)
				tmp[i] = strdup(bb[i]);
			tmp[n] = NULL;
			au->source_list = tmp;
			break;
		case AUSOURCE_BUFFER:
			n = 0;
			tmp = malloc(2*sizeof(char *));
			tmp[0] = strdup(b);
			tmp[1] = NULL;
			au->source_list = tmp;
			break;
		case AUSOURCE_BUFFER_ARRAY:
			n = 0;
			while (bb[n])
				n++;
			tmp = malloc(n*sizeof(char *));
			for (i=0; i<n; i++)
				tmp[i] = strdup(bb[i]);
			tmp[n] = NULL;
			au->source_list = tmp;
			break;
		default:
			errno = EINVAL;
			return NULL;
			break;
	}
	au->source = source;
	au->list_idx = 0;
	au->fd = -1;
	au->cur_buf = NULL;
	list_create(&au->le);

	return au;
}


int auparse_reset(auparse_state_t *au)
{
	if (au == NULL) {
		errno = EINVAL;
		return 0;
	}

	switch (au->source)
	{
		case AUSOURCE_LOGS:
		case AUSOURCE_FILE:
		case AUSOURCE_FILE_ARRAY:
			if (au->fd >= 0) {
				close(au->fd);
				au->fd = -1;
			}
		/* Fall through */
		case AUSOURCE_BUFFER:
		case AUSOURCE_BUFFER_ARRAY:
			au->list_idx = 0;
			break;
	}
	return 1;
}


int ausearch_set_param(auparse_state_t *au, const char *field, const char *op,
	const char *value, austop_t where)
{
	return 1;
}


int ausearch_clear_param(auparse_state_t *au)
{
	return 1;
}


int auparse_destroy(auparse_state_t *au)
{
	if (au->source_list) {
		int n = 0;
		while (au->source_list[n]) 
			free(au->source_list[n++]);
		free(au->source_list);
	}
	return 1;
}


/* Functions that traverse events */
int ausearch_next_event(auparse_state_t *au)
{
	return 1;
}


int auparse_next_event(auparse_state_t *au)
{
// FIXME: This is where the work currently is

	// Brute force go to next event 
	// Tear down old event info

	// Read from buffer until event is complete or there are no more buffs
		// while get_next_buffer
			// for each event in buffer
				// Update the per event data
				// Set cursor to first record of new event
				// Set other cursor to 1st field of cur record

	return 1;
}


/* Accessors to event data */
const event_t *auparse_get_timestamp(auparse_state_t *au)
{
	return NULL;
}


time_t auparse_get_time(auparse_state_t *au)
{
}


time_t auparse_get_milli(auparse_state_t *au)
{
}


unsigned long auparse_get_serial(auparse_state_t *au)
{
}


const char *auparse_get_node(auparse_state_t *au)
{
	return NULL;
}


int auparse_timestamp_compare(event_t *e1, event_t *e2)
{
}


/* Functions that traverse records in the same event */
int auparse_first_record(auparse_state_t *au)
{
	return 1;
}


int auparse_next_record(auparse_state_t *au)
{
	return 1;
}


/* Accessors to record data */
int auparse_get_type(auparse_state_t *au)
{
	return 1;
}


int auparse_first_field(auparse_state_t *au)
{
	return 1;
}


int auparse_next_field(auparse_state_t *au)
{
	return 1;
}


const char *auparse_find_field(auparse_state_t *au, const char *name)
{
	return NULL;
}


const char *auparse_find_field_next(auparse_state_t *au)
{
	return NULL;
}


/* Accessors to field data */
const char *auparse_get_field_name(auparse_state_t *au)
{
	return NULL;
}


const char *auparse_get_field_str(auparse_state_t *au)
{
	return NULL;
}


int auparse_get_field_int(auparse_state_t *au)
{
}


const char *auparse_interpret_field(auparse_state_t *au)
{
	return NULL;
}


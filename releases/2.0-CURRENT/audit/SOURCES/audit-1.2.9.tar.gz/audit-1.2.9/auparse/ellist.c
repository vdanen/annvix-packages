/*
* ellist.c - Minimal linked list library
* Copyright (c) 2006 Red Hat Inc., Durham, North Carolina.
* All Rights Reserved. 
*
* This software may be freely redistributed and/or modified under the
* terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2, or (at your option) any
* later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; see the file COPYING. If not, write to the
* Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* Authors:
*   Steve Grubb <sgrubb@redhat.com>
*/

#include <stdlib.h>
#include <string.h>
#include "ellist.h"

void list_create(event_list_t *l)
{
	l->head = NULL;
	l->cur = NULL;
	l->cnt = 0;
	l->e.milli = 0L;       
	l->e.sec = 0L;         
	l->e.serial = 0L;      
}

void list_last(event_list_t *l)
{
        register lnode* window;
	
	if (l->head == NULL)
		return;

        window = l->head;
	while (window->next)
		window = window->next;
	l->cur = window;
}

lnode *list_next(event_list_t *l)
{
	if (l->cur == NULL)
		return NULL;
	l->cur = l->cur->next;
	return l->cur;
}

lnode *list_prev(event_list_t *l)
{
	if (l->cur == NULL)
		return NULL;

	if (l->cur->item <= 0)
		return NULL;

	list_find_item(l, l->cur->item-1);
	return l->cur;
}

void list_append(event_list_t *l, lnode *node)
{
	lnode* newnode;

	newnode = malloc(sizeof(lnode));

	if (node->message)
		newnode->message = node->message;
	else
		newnode->message = NULL;

	newnode->type = node->type;
	newnode->a0 = node->a0;
	newnode->item = l->cnt; 
	newnode->next = NULL;

	// if we are at top, fix this up
	if (l->head == 0)
		l->head = newnode;
	else	// Otherwise add pointer to newnode
		l->cur->next = newnode;

	// make newnode current
	l->cur = newnode;
	l->cnt++;
}

int list_find_item(event_list_t *l, unsigned int i)
{
        register lnode* window;
                                                                                
	if (l->cur && (l->cur->item <= i))
		window = l->cur;	/* Try to use where we are */
	else
        	window = l->head;	/* Can't, start over */

	while (window) {
		if (window->item == i) {
			l->cur = window;
			return 1;
		} else
			window = window->next;
	}
	return 0;
}

void list_clear(event_list_t* l)
{
	lnode* nextnode;
	register lnode* current;

	current = l->head;
	while (current) {
		nextnode=current->next;
		if (current->message)
			free(current->message);
		free(current);
		current=nextnode;
	}
	l->head = NULL;
	l->cur = NULL;
	l->cnt = 0;
	l->e.milli = 0L;       
	l->e.sec = 0L;         
	l->e.serial = 0L;      
}

int list_get_event(event_list_t* l, event_t *e)
{
	if (l == NULL || e == NULL)
		return 0;

	e->sec = l->e.sec;
        e->milli = l->e.milli;
        e->serial = l->e.serial;
	return 1;
}

lnode *list_find_msg(event_list_t *l, int i)
{
        register lnode* window;
                                                                                
       	window = l->head;	/* start at the beginning */
	while (window) {
		if (window->type == i) {
			l->cur = window;
			return window;
		} else
			window = window->next;
	}
	return NULL;
}

lnode *list_find_msg_range(event_list_t *l, int low, int high)
{
        register lnode* window;

	if (high <= low)
		return NULL;

       	window = l->head;	/* Start at the beginning */
	while (window) {
		if (window->type >= low && window->type <= high) {
			l->cur = window;
			return window;
		} else
			window = window->next;
	}
	return NULL;
}


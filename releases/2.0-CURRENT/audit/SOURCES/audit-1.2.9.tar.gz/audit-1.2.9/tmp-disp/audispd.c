/* audispd.c -- 
 * Copyright 2006 Red Hat Inc., Durham, North Carolina.
 * All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors:
 *   Steve Grubb <sgrubb@redhat.com>
 *
 */

#include "config.h"
#include <locale.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <libgen.h>
#include <errno.h>
#include <dirent.h>
#include <fcntl.h>

#include "libaudit.h"
#include "private.h"


/* Local prototypes */
typedef enum { EN_YES, EN_NO } en_t;

struct disp_conf
{
        en_t enabled;		/* This dispatcher is enabled or not */
        char *path;
};

struct nv_pair
{
	const char *name;
	const char *value;
};

struct kw_pair 
{
	const char *name;
	int (*parser)(const char *, int, struct disp_conf *);
};

struct nv_list
{ 
	const char *name;
	int option;
};

static int load_config(const char *fname, struct disp_conf *config);
static char *get_line(FILE *f, char *buf);
static int nv_split(char *buf, struct nv_pair *nv);
static const struct kw_pair *kw_lookup(const char *val);
static int enabled_parser(const char *val, int line, struct disp_conf *config);
static int path_parser(const char *val, int line, struct disp_conf *config);
static int sanity_check(struct disp_conf *config);

// Local data
static const char *config_dir = "/etc/audisp.d";

static const struct kw_pair keywords[] = 
{
  {"enabled",	enabled_parser },
  {"path",	path_parser },
  { NULL,	NULL }
};

static const struct nv_list enabled_options[] =
{
  {"yes",  EN_YES },
  {"no",   EN_NO },
  { NULL,  0 }
};

/*
 * main
 */
int main(int argc, char *argv[])
{
	DIR *dirfp;
	struct dirent *direntry;
	struct disp_conf config;

	setlocale (LC_ALL, "");
	set_aumessage_mode(MSG_SYSLOG, DBG_NO);
	openlog("audispd", LOG_PID, LOG_DAEMON);
	audit_msg(LOG_NOTICE, "audisp starting...");

#ifndef DEBUG
	// Make sure we are root
	if (getuid() != 0) {
		audit_msg(LOG_ERR, "You must be root to run this program.");
		return 4;
	}
#endif

	(void)chdir("/");

	// Read config files
	dirfp = opendir(config_dir);
	if (! dirfp) {
		audit_msg(LOG_ERR, "Unable to read directory: %s", config_dir);
		return 1;
	}

	/* Get the list of files in the directory */
	while ((direntry = readdir(dirfp)) != 0) {
		if (direntry->d_name[0] != '.') {
			// If found an enabled config, exec it
			char fname[PATH_MAX];
			strcpy(fname, config_dir);
			strcat(fname, "/");
			strcat(fname, direntry->d_name);
			if (load_config(fname, &config) == 0) {
				if (config.enabled == EN_YES) {
					char *argv[2];

					audit_msg(LOG_ERR,
						"Starting: %s", config.path);
					argv[0] = config.path;
					argv[1] = NULL;
					execve(config.path, argv, NULL);
					audit_msg(LOG_ERR,
						"Failed to exec: %s (%s)",
						config.path, strerror(errno));

					return 1; // exec failed !
				}
			}
		}
	}
	closedir(dirfp);
	audit_msg(LOG_WARNING, "No configuration files enabled - exiting.");

	// No config files exit
	return 0;
}



/*
 * Set everything to its default value
*/
static void clear_config(struct disp_conf *config)
{
	config->enabled = EN_NO;
	config->path = NULL;
}

static int load_config(const char *fname, struct disp_conf *config)
{
	int fd, rc, lineno = 1;
	struct stat st;
	FILE *f;
	char buf[128];

	clear_config(config);

	/* open the file */
	rc = open(fname, O_NOFOLLOW|O_RDONLY);
	if (rc < 0) {
		if (errno != ENOENT) {
			audit_msg(LOG_ERR, "Error opening config file (%s)", 
				strerror(errno));
			return 1;
		}
		audit_msg(LOG_WARNING,
			"Config file %s doesn't exist, skipping", fname);
		return 0;
	}
	fd = rc;

	/* check the file's permissions: owned by root, not world writable,
	 * not symlink.
	 */
	audit_msg(LOG_DEBUG, "Config file %s opened for parsing", fname);
	if (fstat(fd, &st) < 0) {
		audit_msg(LOG_ERR, "Error fstat'ing config file (%s)", 
			strerror(errno));
		return 1;
	}
	if (st.st_uid != 0) {
		audit_msg(LOG_ERR, "Error - %s isn't owned by root", fname);
		return 1;
	}
	if ((st.st_mode & S_IWOTH) == S_IWOTH) {
		audit_msg(LOG_ERR, "Error - %s is world writable", fname);
		return 1;
	}
	if (!S_ISREG(st.st_mode)) {
		audit_msg(LOG_ERR, "Error - %s is not a regular file", fname);
		return 1;
	}

	/* it's ok, read line by line */
	f = fdopen(fd, "r");
	if (f == NULL) {
		audit_msg(LOG_ERR, "Error - fdopen failed (%s)", 
			strerror(errno));
		return 1;
	}

	while (get_line(f, buf)) {
		// convert line into name-value pair
		const struct kw_pair *kw;
		struct nv_pair nv;
		rc = nv_split(buf, &nv);
		switch (rc) {
			case 0: // fine
				break;
			case 1: // not the right number of tokens.
				audit_msg(LOG_ERR, 
				"Wrong number of arguments for line %d in %s", 
					lineno, fname);
				break;
			case 2: // no '=' sign
				audit_msg(LOG_ERR, 
					"Missing equal sign for line %d in %s", 
					lineno, fname);
				break;
			default: // something else went wrong... 
				audit_msg(LOG_ERR, 
					"Unknown error for line %d in %s", 
					lineno, fname);
				break;
		}
		if (nv.name == NULL) {
			lineno++;
			continue;
		}

		/* identify keyword or error */
		kw = kw_lookup(nv.name);
		if (kw->name == NULL) {
			audit_msg(LOG_ERR, 
				"Unknown keyword \"%s\" in line %d of %s", 
				nv.name, lineno, fname);
			fclose(f);
			return 1;
		}

		/* dispatch to keyword's local parser */
		rc = kw->parser(nv.value, lineno, config);
		if (rc != 0) {
			fclose(f);
			return 1; // local parser puts message out
		}

		lineno++;
	}

	fclose(f);
	return sanity_check(config);
}

static char *get_line(FILE *f, char *buf)
{
	if (fgets_unlocked(buf, 128, f)) {
		/* remove newline */
		char *ptr = strchr(buf, 0x0a);
		if (ptr)
			*ptr = 0;
		return buf;
	}
	return NULL;
}

static int nv_split(char *buf, struct nv_pair *nv)
{
	/* Get the name part */
	char *ptr;

	nv->name = NULL;
	nv->value = NULL;
	ptr = strtok(buf, " ");
	if (ptr == NULL)
		return 0; /* If there's nothing, go to next line */
	if (ptr[0] == '#')
		return 0; /* If there's a comment, go to next line */
	nv->name = ptr;

	/* Check for a '=' */
	ptr = strtok(NULL, " ");
	if (ptr == NULL)
		return 1;
	if (strcmp(ptr, "=") != 0)
		return 2;

	/* get the value */
	ptr = strtok(NULL, " ");
	if (ptr == NULL)
		return 1;
	nv->value = ptr;

	/* Make sure there's nothing else */
	ptr = strtok(NULL, " ");
	if (ptr)
		return 1;

	/* Everything is OK */
	return 0;
}

static const struct kw_pair *kw_lookup(const char *val)
{
	int i = 0;
	while (keywords[i].name != NULL) {
		if (strcasecmp(keywords[i].name, val) == 0)
			break;
		i++;
	}
	return &keywords[i];
}
 

static int enabled_parser(const char *val, int line, struct disp_conf *config)
{
	int i;

	audit_msg(LOG_DEBUG, "enabled_parser called with: %s", val);
	for (i=0; enabled_options[i].name != NULL; i++) {
		if (strcasecmp(val, enabled_options[i].name) == 0) {
			config->enabled = enabled_options[i].option;
			return 0;
		}
	}
	audit_msg(LOG_ERR, "Option %s not found - line %d", val, line);
	return 1;
}

static int path_parser(const char *val, int line, struct disp_conf *config)
{
	char *dir = NULL, *tdir, *base;
	int fd;
	struct stat buf;

	audit_msg(LOG_DEBUG, "path_parser called with: %s", val);
	if (val == NULL) {
		config->path = NULL;
		return 0;
	}

	/* split name into dir and basename. */
	tdir = strdup(val);
	if (tdir)
		dir = dirname(tdir);
	if (dir == NULL || strlen(dir) < 4) { //  '/var' is shortest dirname
		free(tdir);
		audit_msg(LOG_ERR,
			"The directory name: %s is too short - line %d",
			dir, line);
		return 1;
	}

	free((void *)tdir);
	base = basename((char *)val);
	if (base == 0 || strlen(base) == 0) {
		audit_msg(LOG_ERR, "The file name: %s is too short - line %d",
			base, line);
		return 1;
	}
	/* if the file exists, see that its regular, owned by root,
	 * and not world anything */
	fd = open(val, O_RDONLY);
	if (fd < 0) {
		audit_msg(LOG_ERR, "Unable to open %s (%s)", val,
			strerror(errno));
		return 1;
	}
	if (fstat(fd, &buf) < 0) {
		audit_msg(LOG_ERR, "Unable to stat %s (%s)", val,
			strerror(errno));
		return 1;
	}
	close(fd);
	if (!S_ISREG(buf.st_mode)) {
		audit_msg(LOG_ERR, "%s is not a regular file", val);
		return 1;
	}
	if (buf.st_uid != 0) {
		audit_msg(LOG_ERR, "%s is not owned by root", val);
		return 1;
	}
	if ((buf.st_mode & (S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IXGRP)) !=
			   (S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IXGRP)) {
		audit_msg(LOG_ERR, "%s permissions should be 0750", val);
		return 1;
	}
	if (config->path)
		free((void *)config->path);
	config->path = strdup(val);
	if (config->path == NULL)
		return 1;
	return 0;
}

/*
 * This function is where we do the integrated check of the dispatcher config
 * options. At this point, all fields have been read. Returns 0 if no
 * problems and 1 if problems detected.
 */
static int sanity_check(struct disp_conf *config)
{
	/* Error checking */
	if (config->enabled == EN_YES && config->path == NULL) {
		audit_msg(LOG_ERR, 
		    "Error - config enabled and no path");
		return 1;
	}
	return 0;
}

void free_config(struct disp_conf *config)
{
	free((void*)config->path);
}


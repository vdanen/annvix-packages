/* ausearch-options.h -- 
 * Copyright 2005 Red Hat Inc., Durham, North Carolina.
 * All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors:
 *   Steve Grubb <sgrubb@redhat.com>
 * 
 */

#ifndef AUSEARCH_OPTIONS_H
#define AUSEARCH_OPTIONS_H

#include <time.h>
#include <sys/types.h>
#include "ausearch-int.h"

/* Global variables that describe what search is to be performed */
extern time_t start_time, end_time;
extern unsigned int event_id;
extern gid_t event_gid, event_egid;
extern ilist *event_type;
extern pid_t event_pid, event_ppid;
extern int event_success;
extern int event_exact_match;
extern uid_t event_uid, event_euid, event_loginuid;
extern const char *event_key;
extern const char *event_filename;
extern const char *event_exe;
extern const char *event_comm;
extern const char *event_hostname;
extern const char *event_terminal;
extern const char *event_subject;
extern const char *event_object;
extern int event_syscall;
extern int event_ua, event_ga;

/* Data type to govern output format */
typedef enum { RPT_RAW, RPT_INTERP, RPT_PRETTY } report_t;
extern report_t report_format;

/* Function to process commandline options */
extern int check_params(int count, char *vars[]);

#endif


/* auditd-dispatch.c -- 
 * Copyright 2005-2006 Red Hat Inc., Durham, North Carolina.
 * All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors:
 *   Steve Grubb <sgrubb@redhat.com>
 *   Junji Kanemaru <junji.kanemaru@linuon.com>
 */

#include "config.h"
#include <unistd.h>
#include <sys/uio.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

#include "libaudit.h"
#include "private.h"
#include "auditd-dispatch.h"

/* This is the communications channel between auditd & the dispatcher */
static int disp_pipe[2];
static pid_t pid = 0;

/* set_flags: to set flags to file desc */
static int set_flags(int fn, int flags)
{
	int fl;

	if ((fl = fcntl(fn, F_GETFL, 0)) < 0) {
		audit_msg(LOG_ERR, "fcntl failed. Cannot get flags (%s)\n", 
			strerror(errno));
		 return fl;
	}

	fl |= flags;

	return fcntl(fn, F_SETFL, fl);
}

/* This function returns 1 on error & 0 on success */
int init_dispatcher(const struct daemon_conf *config)
{
	disp_pipe[0] = -1;
	disp_pipe[1] = -1;
	if (config->dispatcher == NULL) 
		return 0;

	if (socketpair(AF_UNIX, SOCK_STREAM, 0, disp_pipe)) {
		audit_msg(LOG_ERR, "Failed creating disp_pipe");
		return 1;
	}

	/* Make both disp_pipe non-blocking */
	if (config->qos == QOS_NON_BLOCKING) {
		if (set_flags(disp_pipe[0], O_NONBLOCK) < 0) {
			audit_msg(LOG_ERR, "Failed to set O_NONBLOCK flag");
			return 1;
		}
		if (set_flags(disp_pipe[1], O_NONBLOCK) < 0) {
			audit_msg(LOG_ERR, "Failed to set O_NONBLOCK flag");
			return 1;
		}
	}

	// do the fork
	pid = fork();
	switch(pid) {
		case 0:	// child
			dup2(disp_pipe[0], 0);
			close(disp_pipe[0]);
			close(disp_pipe[1]);
			setsid();
			execl(config->dispatcher, config->dispatcher, NULL);
			audit_msg(LOG_ERR, "exec() failed");
			exit(1);
			break;
		case -1:	// error
			return 1;
			break;
		default:	// parent
			close(disp_pipe[0]);
			audit_msg(LOG_INFO, "Started dispatcher: %s pid: %u",
					config->dispatcher, pid);
			break;
	}

	return 0;
}

void shutdown_dispatcher(void)
{
	// kill child
	if (pid)
		kill(pid, SIGTERM);
	// wait for term
	// if not in time, send sigkill
	pid = 0;
}

void dispatch_event(const struct audit_reply *rep)
{
	int rc, count = 0;
	struct iovec vec[2];
	struct audit_dispatcher_header hdr;

	if (disp_pipe[1] == -1)
		return;

	hdr.ver = AUDISP_PROTOCOL_VER; /* Hard-coded to current protocol */
	hdr.hlen = sizeof(struct audit_dispatcher_header);
	hdr.type = rep->type;
	hdr.size = rep->len;

	vec[0].iov_base = (void*)&hdr;
	vec[0].iov_len = sizeof(hdr);
	vec[1].iov_base = (void*)rep->message;
	vec[1].iov_len = rep->len;

	do {
		rc = writev(disp_pipe[1], vec, 2);
	} while (rc < 0 && errno == EAGAIN && count++ < 10);

	// close pipe if no child or peer has been lost
	if (rc <= 0) {
		if (errno == EPIPE) {
			disp_pipe[1] = -1;
			shutdown_dispatcher();
		} else {
			audit_msg(LOG_ERR, 
				"dispatch err (%s) event lost",
				errno == EAGAIN ? "pipe full" :
				strerror(errno));
		}
	}
}


/*
* eevent_list_t.h - Header file for ellist.c
* Copyright (c) 2006 Red Hat Inc., Durham, North Carolina.
* All Rights Reserved.
*
* This software may be freely redistributed and/or modified under the
* terms of the GNU General Public License as published by the Free
* Software Foundation; either version 2, or (at your option) any
* later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; see the file COPYING. If not, write to the
* Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* Authors:
*   Steve Grubb <sgrubb@redhat.com>
*/

#ifndef ELLIST_HEADER
#define ELLIST_HEADER

#include "config.h"
#include "auparse-defs.h"
#include <sys/types.h>


/* This is the node of the linked list. message & item are the only elements
 * at this time. Any data elements that are per item goes here. */
typedef struct _lnode{
  char *message;	// The whole unparsed message
  int type;             // message type (KERNEL, USER, LOGIN, etc)
  unsigned long long a0;	// argv 0
  unsigned int item;	// Which item of the same event
  struct _lnode* next;	// Next node pointer
} lnode;

/* This is the linked list head. Only data elements that are 1 per
 * event goes here. */
typedef struct {
  lnode *head;		// List head
  lnode *cur;		// Pointer to current node
  unsigned int cnt;	// How many items in this list

			// Data we add as 1 per event
  event_t e;		// event - time & serial number
} event_list_t;

void list_create(event_list_t *l);
static inline void list_first(event_list_t *l) { l->cur = l->head; }
void list_last(event_list_t *l);
lnode *list_next(event_list_t *l);
lnode *list_prev(event_list_t *l);
static inline lnode *list_get_cur(event_list_t *l) { return l->cur; }
void list_append(event_list_t *l, lnode *node);
void list_clear(event_list_t* l);
int list_get_event(event_list_t* l, event_t *e);

/* Given a numeric index, find that record. */
int list_find_item(event_list_t *l, unsigned int i);

/* Given a message type, find the matching node */
lnode *list_find_msg(event_list_t *l, int i);

/* Given two message types, find the first matching node */
lnode *list_find_msg_range(event_list_t *l, int low, int high);

#endif


import struct, os
class AuditMsg:
    header_format="iiii"
    header_size = struct.calcsize(header_format)

    def __init__(self):
        self.version  = None
        self.size     = None
        self.msg_type = None
        self.length   = None
        self.body     = None
        
    def read_from_fd(self, fd):
        header = os.read(fd, AuditMsg.header_size)
        if len(header) != AuditMsg.header_size:
            return False

        # Read the header
        self.version, self.size, self.msg_type, self.length = \
                      struct.unpack(AuditMsg.header_format, header)

        # Read the body
        self.body = os.read(fd, self.length)
        if len(self.body) < self.length:
            return False
        return True

    def get_header(self):
        return struct.pack(AuditMsg.header_format,
                           self.version, self.size, self.msg_type, self.length)

    def get_body(self):
        return self.body

    def get_type(self):
        return self.msg_type

    def binary(self):
        return self.get_header() + self.get_body()

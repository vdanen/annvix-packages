#!/usr/bin/perl
#
# $Id: format_subdomain_files.pl 4425 2005-05-03 22:37:48Z sarnold $
#
# ----------------------------------------------------------------------
#    PROPRIETARY DATA of IMMUNIX INC.
#    Copyright (c) 2004, IMMUNIX (All rights reserved)
#
#    This document contains trade secret data which is the property
#    of IMMUNIX Inc.  This document is submitted to recipient in
#    confidence. Information contained herein may not be used, copied
#    or disclosed in whole or in part except as permitted by written
#    agreement signed by an officer of IMMUNIX, Inc.
# ----------------------------------------------------------------------

use strict;

#use diagnostics;

my $tabwidth   = 8;
my $right_edge = 80;

my @columns;
my @formline;
my @line;
my @line_total;

open( FILE, $ARGV[0] );
while (<FILE>) {
    chomp;

    #my @elements = split '\s+', $_;
    my @change;
    
    my $counter = 0;
    my $total   = 0;
    !/{$/ and do {
        for my $x ( split '\s+', $_ ) {
            last if $x =~ /^#/;
	    $change[$counter] =
              ( $columns[$counter] || 0 ) < length($x)
              ? length($x)
              : ( $columns[$counter] || 0 );
            $counter++;
        }
        map { $total += ( $_ + $tabwidth ) } @change;
        $counter = 0;
        for (@change) {
            $columns[$counter] =
              ( $change[$counter] || 0 ) > $columns[$counter]
              ? $change[$counter]
              : $columns[$counter]
              if $total < $right_edge;
            $counter++;
        }
    };
    push ( @line, $_ );
    push (@line_total, ($total || 0));
}
close(FILE);

map { push ( @formline, '@' . '<' x ( $_ + $tabwidth ) ) } @columns;

open( FILE, "> $ARGV[0]" ) or die "cannot open $ARGV[0] for writing";
for (@line) {
    my $line_total = shift @line_total;
    my @elements;
    my $comments;
    /{$/ and do {
        print FILE join " ", split;
        print FILE "\n";
        next;
    };
    /(.*)?(#.*)/ and do {
        @elements = split '\s+', $1;
        $comments = $2;
      }
      or do {
        @elements = split '\s+', $_;
      };
    if ( scalar(@elements) > 0 ) {
        my $formline;
        if ( $line_total > $right_edge || scalar(@elements) > scalar(@columns) )
        {
            map { $formline .= '@' . '<' x ( length($_) + $tabwidth ) }
              @elements;
        }
        else {
            $formline = join '', @formline[ 0 .. ( scalar(@elements) - 1 ) ];
        }
        $^A = "";
        formline( $formline, @elements );
        print FILE $^A;
    }
    print FILE "\t" . $comments if $comments;
    print FILE "\n";
}

close FILE;

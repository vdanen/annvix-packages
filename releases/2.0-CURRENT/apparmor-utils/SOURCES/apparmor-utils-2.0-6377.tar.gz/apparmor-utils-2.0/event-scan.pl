#!/usr/bin/perl -w

use strict;
use Storable;
use Date::Parse;

my $hostname = `/bin/hostname -f`;
chomp($hostname);

my %config;
open(CFG, "/etc/notify.cfg") or exit 0;
while(<CFG>) {
  chomp;
  $config{$1} = $2 if /^(\S+)\s+(.+)\s*$/;
}
close(CFG);

exit 0 unless($config{terse_email}   ||
              $config{summary_email} ||
              $config{verbose_email});

# if there's no frequency in the config file, default to five minutes
if($config{terse_email}) {
  $config{terse_freq} ||= 300;
}

if($config{summary_email}) {
  $config{summary_freq} ||= 300;
}

if($config{verbose_email}) {
  $config{verbose_freq} ||= 300;
}

my %translate = (
  x      => "running",                r      => "reading",
  w      => "writing to",             l      => "linking to",
  wl     => "writing and linking to", "link" => "linking from"
);  


my $REdate = '\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2}';

# what time is it right... NOW
my $now  = time;

# load in the db or set it to an empty hashref
my $db = eval { retrieve('/var/cache/ssm_notify.db') } || { };

# make sure this stuff is initialized
$db->{scan_last}      ||= 0;

$db->{terse}          ||= { };
$db->{terse_last}     ||= 0;
$db->{terse_notify}   ||= 0;

$db->{summary}        ||= { };
$db->{summary_last}   ||= 0;
$db->{summary_notify} ||= 0;

$db->{verbose}        ||= [ ];
$db->{verbose_last}   ||= 0;
$db->{verbose_notify} ||= 0;

# let's keep track of how many events we added this scan for shits and giggles
my $added = 0;

open(LOG, "/var/log/messages") or die "can't read messages file while scanning for security events: $!";
while(<LOG>) {
  # we don't care about anything other than these message types
  next unless /SubDomain|Phoenixd|Immunix SG|ImmunixOS format error/;

  # skip some noise
  next if /^(SubDomain: SubDomain initialized|Loading SubDomain modules succeeded|SubDomain: sysctl_add|SubDomain: SubDomain protection removed|Unloading SubDomain modules succeeded)/;

  chomp;

  #          date     host    mesg
  if(/^\s*($REdate)\s+(\S+)\s+(.+)$/) {
    my ($date, $host, $mesg) = ($1, $2, $3, $4);

    # skip all *guard messages we've already seen
    my $timestamp = str2time($date);
    next if $timestamp <= $db->{scan_last};

    my ($prog, $pid);
    if($mesg =~ /^(\S+):\s+(.+)$/) {
      ($prog, $mesg) = ($1, $2);
  
      if($prog =~ /^(.+)\[(\d+)\]$/) {
        ($prog, $pid) = ($1, $2);
      }
    }

    push @{$db->{verbose}}, "$date $mesg" if $config{verbose_email};

    # standardise and  clean up the *guard messages to get rid of noise 
    # from info we don't report yet so they'll collapse down better

    $mesg =~ s/\s+$//;

    $mesg =~ s/ImmunixOS format error - mismatch of 0 in (\S+) called by (\S+)/FormatGuard stopped a format specification error in $prog/;

    $mesg =~ s/Immunix SG 3.0 canary = aff0d died with cadaver [A-Fa-f0-9]+ in procedure (\S+)\./StackGuard stopped a buffer overflow in $prog/;

    #                                     mode           direction  victim   process
    if($mesg =~ m/^SubDomain:\sREJECTING\s(\w+)\saccess\s(to|from)\s(.*?)\s+\((.*?)\(\d+\)/) {
      my ($mode, $victim, $process) = ($1, $3, $4);
      $mesg = "SubDomain prevented $process from $translate{$mode} $victim";
    }

    # in my syslog parse testing, i ran into some kernel messages that didn't 
    # have an associated "program", this should never happen in *guard msgs
    $prog ||= "NULL";

    if($config{terse_email}) {
      # init structure for this msg if it doesn't exist yet
      $db->{terse}->{$prog}          ||= { };
      $db->{terse}->{$prog}->{$mesg} ||= { };
      # bump the counter and store the latest time we've seen it
      $db->{terse}->{$prog}->{$mesg}->{count}++;
      $db->{terse}->{$prog}->{$mesg}->{when} = $timestamp;
    }

    if($config{summary_email}) {
      # init structure for this msg if it doesn't exist yet
      $db->{summary}->{$prog}          ||= { };
      $db->{summary}->{$prog}->{$mesg} ||= { };
      # bump the counter and store the latest time we've seen it
      $db->{summary}->{$prog}->{$mesg}->{count}++;
      $db->{summary}->{$prog}->{$mesg}->{when} = $timestamp;
    }

    $added++;
  }
}
close(LOG);

# print "Added $added events between " . localtime($db->{scan_last}) . " and " . localtime($now) . "\n";

if(keys %{$db->{terse}}) {
  # if we're past the time for the next notification to go out...
  if($db->{terse_notify} <= $now) {
    notify_terse($db);                # ...do the notification
#  } else {
#    print localtime($now) . ": Not doing terse notify until " . localtime($db->{terse_notify}) . "\n";
  }
}

if(keys %{$db->{summary}}) {
  # if we're past the time for the next notification to go out...
  if($db->{summary_notify} <= $now) {
    notify_summary($db);                # ...do the notification
#  } else {
#    print localtime($now) . ": Not doing summary notify until " . localtime($db->{summary_notify}) . "\n";
  }
}

if(@{$db->{verbose}}) {
  # if we're past the time for the next notification to go out...
  if($db->{verbose_notify} <= $now) {
    notify_verbose($db);                # ...do the notification
#  } else {
#    print localtime($now) . ": Not doing verbose notify until " . localtime($db->{verbose_notify}) . "\n";
  }
}


# update the "last time we scanned for events" timestamp
$db->{scan_last} = $now;

# and write the tree back out to the file
store $db, '/var/cache/ssm_notify.db';

exit 0;

#                                       mode            file   process       profile       active
#     if($mesg =~ /SubDomain: REJECTING (\w+) access to (\S+) \((\S+) profile (\S+) active (\S+)\)/) {
#       my ($mode, $file, $process, $profile, $active) = ($1, $2, $3, $4, $5);
# 
#       $process =~ s/\(\d+\)$//;
# 
#       print "SubDomain - $process\n";
#       print "Mode: $mode\n";
#       print "File: $file\n";
#       print "Profile: $profile\n";
#       print "Active: $active\n";
#       print "\n";
#     } elsif ($mesg =~ // ) {
# 
#     } 

sub notify_terse {
  my $db = shift;

#  print "sending terse notification to $config{terse_email}\n";

  my $events = 0;
  for my $prog (keys %{$db->{terse}}) {
    for my $mesg (keys %{$db->{terse}->{$prog}}) {
      $events += $db->{terse}->{$prog}->{$mesg}->{count};
    }
  }

  my $mesg = "$hostname has had $events security events";
  $mesg .= " since " . localtime($db->{terse_last}) if $db->{terse_last};
  open(MAIL, "| mail -s 'Security Events for $hostname' $config{terse_email}");
  print MAIL "$mesg\n";
  close(MAIL);

  # clear the "terse" db
  $db->{terse} = { };
  # ...keep track of when we last sent out a notify
  $db->{terse_last} = $now;
  # ...and update the timer for the soonest they want another notification
  $db->{terse_notify} = $now + $config{terse_freq} - 60;
}

sub notify_summary {
  my $db = shift;

#  print "sending summary notification to $config{summary_email}\n";

  my $text = "$hostname had the following security events since " . localtime($db->{scan_last}) . ":\n\n";
  for my $prog (keys %{$db->{summary}}) {
    for my $mesg (keys %{$db->{summary}->{$prog}}) {
      $text .= $mesg;
      if($db->{summary}->{$prog}->{$mesg}->{count} > 1) {
        $text .= " " . $db->{summary}->{$prog}->{$mesg}->{count} . " times";
        $text .= ", the latest at " . localtime($db->{summary}->{$prog}->{$mesg}->{when});
      } else {
        $text .= " once at " . localtime($db->{summary}->{$prog}->{$mesg}->{when});
      }
      $text .= ".\n";
    }
  }

  open(MAIL, "| mail -s 'Summary of Security Events for $hostname' $config{summary_email}");
  print MAIL "$text\n";
  close(MAIL);

  # clear the "summary" db
  $db->{summary} = { };
  # ...keep track of when we last sent out a notify
  $db->{summary_last} = $now;
  # ...and update the timer for the soonest they want another notification
  $db->{summary_notify} = $now + $config{summary_freq} - 60;
}

sub notify_verbose {
  my $db = shift;

#  print "sending verbose notification to $config{verbose_email}\n";

  my $mesg;
  $mesg .= "$hostname had the following security events since " . localtime($db->{scan_last}) . ":\n\n";
  $mesg .= "$_\n" for @{$db->{verbose}};

  open(MAIL, "| mail -s 'Verbose Security Report for $hostname' $config{verbose_email}");
  print MAIL "$mesg\n";
  close(MAIL);

  # clear the "verbose" db
  $db->{verbose} = [ ];
  # ...keep track of when we last sent out a notify
  $db->{verbose_last} = $now;
  # ...and update the timer for the soonest they want another notification
  $db->{verbose_notify} = $now + $config{verbose_freq} - 60;
}


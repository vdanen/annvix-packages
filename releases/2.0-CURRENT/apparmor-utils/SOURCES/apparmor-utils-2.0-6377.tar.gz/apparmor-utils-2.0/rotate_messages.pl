#!/usr/bin/perl
#
# $Id: rotate_messages.pl 4425 2005-05-03 22:37:48Z sarnold $
#
# ----------------------------------------------------------------------
#    PROPRIETARY DATA of IMMUNIX INC.
#    Copyright (c) 2004, IMMUNIX (All rights reserved)
#
#    This document contains trade secret data which is the property
#    of IMMUNIX Inc.  This document is submitted to recipient in
#    confidence. Information contained herein may not be used, copied
#    or disclosed in whole or in part except as permitted by written
#    agreement signed by an officer of IMMUNIX, Inc.
# ----------------------------------------------------------------------

for $num ( reverse 0..3 ) {
 $nump = $num + 1;
 print STDOUT "num [$num] nump [$nump]\n";
 if ( $num == 0 ) {
   rename( "/var/log/messages", "/var/log/messages.1" );
 } else {
   rename( "/var/log/messages.$num", "/var/log/messages.$nump" ) if ( -e "/var/log/messages.$num");
 }
}
system("/bin/kill -HUP `cat /var/run/syslogd.pid 2> /dev/null` 2> /dev/null || true");

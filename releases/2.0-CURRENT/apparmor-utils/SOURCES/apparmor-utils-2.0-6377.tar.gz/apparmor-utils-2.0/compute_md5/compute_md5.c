/* $Id: compute_md5.c 4425 2005-05-03 22:37:48Z sarnold $ */

/*
     PROPRIETARY DATA of WIREX COMMUNICATIONS, INC.
     Copyright (c) 2000, WireX (All rights reserved)

     This document contains trade secret data which is the property
     of WireX Communications, Inc.  This document is submitted to
     recipient in confidence.  Information contained herein may not
     be used, copied or disclosed in whole or in part except as
     permitted by written agreement signed by an officer of WireX
     Communications, Inc.

     This material is also copyrighted as an unpublished work under
     Sections 104 and 408 of Title 17 of the United States Code.
     Unauthorized use, copying or other reproduction is prohibited
     by law.
*/

#include <elf.h>
#include "md5.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <getopt.h>

/* Some (not so) arbitrary defines */
#define HASH_SIZE 16
#define BUF_SIZE  4096

#define UTIL_NAME "compute_md5"
#define VERSION "$Revision: 1.2 $"
/* Use PERROR to generate an error string with perror(); otherwise use
 * PWARN for error messages */
#define PERROR(fmt, args...) \
	{ if ( !silent ) { char outbuf[1024] ; \
	  		   snprintf ( outbuf , 1024 , fmt , ## args ) ; \
	  		   perror ( outbuf ) ; } }
#define PWARN(fmt, args...) { if (!silent) fprintf ( stderr , fmt , ## args ) ;}
	  
#ifndef TRUE
	          #define TRUE 1
#endif
#ifndef FALSE
	          #define FALSE 0
#endif

struct md5_struct {
	unsigned char hash [16] ;
} ;

struct option long_options [] =
{
	{ "help" , 0 , 0 , 0 } ,
	{ "output-file" , 1 , 0 , 0 } ,
	{ "silent" , 0 , 0, 0 } ,
	{ "version" , 0 , 0, 0 } ,
} ;

/* A global config variable or two, for your pleasure */
int silent = FALSE ;

static void
display_usage ( char * command )
{
	PWARN ( "\nUsage: %s [options] filename(s)\n\n"
		"Computes md5 hash of elf and script files in the same way as\n"
		"the SubDomain kernel module.\n\n"
		"Options:\n"
		"--------\n"
		"-h, --help            Display this text and exit\n"
		"-o [FILE], --output-file=FILE\n"
		"                      Redirect output (stdout) to FILE\n"
		"-s, --silent          Silent: only hash is printed, no errors\n"
		"-v, --version         Display version info and exit\n"
		, command ) ;
}

int 
decode_elf_binary ( FILE * file , char * filename , struct md5_struct * md5 , 
		    Elf32_Ehdr * elf_ex )
{
	Elf32_Phdr * elf_phdata , * elf_ppnt ;
	MD5_CTX ctx ;
	int retval ;
	int i ;
	unsigned char * buf ;

	if ( elf_ex->e_type != ET_EXEC && elf_ex->e_type != ET_DYN )
	{
		PWARN ( "%s in not an elf executable or dynamic file.\n" ,
				filename ) ;
		return -1 ;
	}

	MD5Init ( &ctx , 0 ) ;

	/* load the program header informaiton */
	/* From the elf specification: if e_phoff == 0, then there's no
	 * program headers */
	if ( elf_ex->e_phoff > 0 ) 
	{
		elf_phdata = ( Elf32_Phdr * ) malloc ( elf_ex->e_phentsize *
						       elf_ex->e_phnum ) ;
		if ( !elf_phdata )
		{
			PWARN ( "Error allocating memory.\n" ) ;
			return -1 ;
		}

		retval = fseek ( file , elf_ex->e_phoff , SEEK_SET ) ;
		if ( retval < 0 )
		{
			PERROR ( "Error seeking in %s" , filename ) ;
			free ( elf_phdata ) ;
			return -1 ;
		}

		retval = fread ( elf_phdata , elf_ex->e_phentsize , 
				 elf_ex->e_phnum , file ) ;
		if ( retval < elf_ex->e_phnum )
		{
			PWARN ( "Error reading program headers for %s.\n" ,
					filename ) ;
			free ( elf_phdata ) ;
			return -1 ;
		}

		/* Search for PT_LOAD segments to calculate MD5 */
		for ( i = 0 , elf_ppnt = elf_phdata ; i < elf_ex->e_phnum ;
				i++ , elf_ppnt++ )
			switch ( elf_ppnt->p_type )
			{
				case PT_NULL :
					break ;
				case PT_LOAD :
				{
					buf = (unsigned char * ) malloc 
						(elf_ppnt->p_filesz) ;
					fseek ( file , elf_ppnt->p_offset , 
							SEEK_SET ) ;
					fread ( buf , elf_ppnt->p_filesz , 1 ,
							file ) ;
					MD5Update ( &ctx , ( void * ) buf ,
							elf_ppnt->p_filesz ) ;
					free ( buf ) ;
					break ;
				}
				case PT_DYNAMIC : case PT_INTERP : 
				case PT_NOTE :    case PT_SHLIB : 
				case PT_PHDR :    case PT_LOPROC :
				case PT_HIPROC :
					break ;
				default :
					break ;
			}
		
		MD5Final ( md5->hash , & ctx ) ;
	}
	
	return 0;
}

int
decode_script_binary ( FILE * file , char * filename , struct md5_struct * md5 ,
		       struct stat * stat ) 
{
	MD5_CTX ctx ;
	int retval ;
	int amount_read = 0 , data_to_read = 0 ;
	int filesize ;
	unsigned char * buf ;

	/* Oops, gotta back up to the beginning */
	fseek ( file , 0 , SEEK_SET ) ;
	
	filesize = stat->st_size ;

	buf = ( unsigned char * ) malloc ( BUF_SIZE ) ;
	if ( !buf )
	{
		PWARN ( "Error allocating memory.\n" ) ;
		return -1 ;
	}

	MD5Init ( &ctx , 0 ) ;

	while ( amount_read < filesize )
	{
		data_to_read = ( amount_read + BUF_SIZE < filesize )
			       ? BUF_SIZE
			       : ( filesize - amount_read ) ;

		retval = fread ( buf , data_to_read , 1 , file ) ;

		MD5Update ( &ctx , buf , data_to_read ) ;

		amount_read += data_to_read ;
	} /* while */

	free ( buf ) ;

	MD5Final ( md5->hash , &ctx ) ;

	return 0 ;
}

int
decode_binary ( unsigned char * filename , struct md5_struct * md5 )
{
	Elf32_Ehdr elf_ex ;
	FILE * file ;
	int retval ;
	struct stat stat ;
	
	/* open file */
	file = fopen ( filename , "r" ) ;
	if ( !file )
	{
		PERROR ( "Unable to open %s" , filename ) ;
		return -1 ;
	}

	retval = fstat ( fileno ( file ) , &stat ) ;
	if ( retval < 0 )
	{
		PERROR ( "Unable to stat %s" , filename ) ;
		return -1 ;
	}
	
	if ( !S_ISREG ( stat.st_mode ) )
	{
		PWARN ( "%s is not a regular file.\n" , filename ) ;
		return -1 ;
	}

	/* Read "magic" bits from file to determine filetype */
	retval = fread ( &elf_ex , 1 , sizeof ( Elf32_Ehdr ) , file ) ;
	if ( retval < 2 )	/* Must be able to read at least two bytes */
	{
		PWARN ( "Error reading file %s: not enough data\n" , 
				filename ) ;
		return -1 ;
	}

	/* Are we an elf file? */
	if ( elf_ex.e_ident[0] == 0x7f &&
	     strncmp ( &elf_ex.e_ident[1] , "ELF" , 3 ) == 0 )
	{
		retval = decode_elf_binary ( file , filename , md5 , &elf_ex ) ;
		goto out ;
	}

	/* Are we a script? */
	if ( strncmp ( &elf_ex.e_ident[0] , "#!" , 2 ) == 0 )
	{
		retval = decode_script_binary ( file , filename , md5 , &stat );
		goto out ;
	}
	/* I have no fscking clue what kind of poo you threw at me. */
	PWARN ( "Unknown file type: %s -- unable to compute md5.\n" , 
			filename ) ;
	retval = -1 ;

out:
	fclose ( file ) ;
	return retval ;
}

int main ( int argc , char * argv [] )
{
	struct md5_struct md5 ;
	int i , j ;
	int error = 0 ;
	FILE * outfile = stdout ;
	int c , o ;
	char * alt_output_file = NULL ;

	while (( c = getopt_long ( argc , argv , "hvso:" , 
			long_options , &o )) != -1 )
		switch ( c ) 
		{
		    case 0:
			switch ( o ) 
			{
			    case 0:
				display_usage ( argv[0] ) ;
				exit ( 0 ) ;
				break ;
			    case 1:
				alt_output_file = optarg ;
				break ;
			    case 2:
				silent = TRUE ;
				break ;
			    case 3:
				printf ( "%s %s\n" , UTIL_NAME , VERSION ) ;
				exit ( 0 ) ;
				break ;
			    default:
				display_usage ( argv[0] ) ;
				exit ( 0 ) ;
				break ;
			}
			break ;
		    case 'h':
			display_usage ( argv[0] ) ;
			exit ( 0 ) ;
			break ;
		    case 'o':
			alt_output_file = optarg ;
			break ;
		    case 's':
			silent = TRUE ;
			break ;
		    case 'v':
			printf ( "%s %s\n" , UTIL_NAME , VERSION ) ;
			exit ( 0 ) ;
			break ;
		}
		
	if ( optind == argc )
	{
		display_usage ( argv[0] ) ;
		exit ( -1 ) ;
	}

	if ( alt_output_file )
	{
		outfile = fopen ( alt_output_file , "w" ) ;
		if ( !outfile )
		{
			PERROR ( "Unable to open output file %s" , 
					alt_output_file ) ;
			exit ( -1 ) ;
		}
	}

	for ( j = optind ; j < argc ; j++ )
	{
		memset ( md5.hash , 0 , HASH_SIZE ) ;
		if ( decode_binary ( argv[j] , &md5 ) == 0 ) 
		{
			if ( !silent )
				fprintf ( outfile , "%s: " , argv[j] ) ;
			for ( i = 0 ; i < HASH_SIZE ; i++ )
				fprintf ( outfile , "%02x" , md5.hash[i] ) ;
			fprintf ( outfile , "\n" ) ;
		}
		else
		{
			//printf ( "Error computing hash for %s\n" , argv[j] ) ;
			error = -1 ;
		}
	}

	return error ;
}

#!/usr/bin/perl
# Ken's subdomain profiler doo dad
# Author: Ken Brush
# Revision: $Id: kenprof.pl 4425 2005-05-03 22:37:48Z sarnold $
# ----------------------------------------------------------------------
#    PROPRIETARY DATA of IMMUNIX INC.
#    Copyright (c) 2004, IMMUNIX (All rights reserved)
#
#    This document contains trade secret data which is the property
#    of IMMUNIX Inc.  This document is submitted to recipient in
#    confidence. Information contained herein may not be used, copied
#    or disclosed in whole or in part except as permitted by written
#    agreement signed by an officer of IMMUNIX, Inc.
# ----------------------------------------------------------------------

#use strict;
#use diagnostics;
use Getopt::Long;
use Carp;

my %profile;

# options variables
my $filename  = '';
my $help      = '';
my $olddir    = '';
my $grouping  = '';
my $testing   = '';
my $splitting = '';

GetOptions(
    'filename|f=s' => \$filename,
    'help|h'       => \$help,
    'olddir|o=s'   => \$olddir,
    'group|g'      => \$grouping,
    'test|t'       => \$testing,
    'split|s'      => \$splitting,
);

&usage && exit if $help;

sub usage {
    print <<EOF;
Usage: $0 -f <subdomain logfile>
Options: 
\t-f,--filename\tsubdomain logfile to use
\t-h,--help\tDisplay this message
\t-o,--olddir\tDirectory of current/old subdomain files to increment
\t-g,--group\tTurn on file grouping
\t-s,--split\tPut every profile in a file named after the profiled program
EOF
}
&use_old if $olddir;

open( LOG, $filename ) and do {
    while (<LOG>) {
        /SubDomain:\s+REJECTING\s+(\w+)\s+access(.*)/ and do {
            my ( $access, $rest, $tmp, $victim_file, $profilename );
            $access = $1;
            $rest   = $2;
            next if $1 !~ /^[r|w|l|x|link]+$/;
            $tmp = ( split '\s+', $rest )[1];
            next
              if ( $access eq "link" && $tmp ne "from" )
              || ( $access ne "link" && $tmp ne "to" );
            my @check = ( $rest =~ /profile/g );
            next if scalar(@check) > 1;

            if ( $access eq "link" ) {
                next;
            }
            else {
                my @rest_vars = $rest =~ /to\s+(.*?)\s.*?profile\s+(.*?)\s+/;
                $victim_file = $rest_vars[0];
                $profilename = $rest_vars[1];
                next if !$profilename;
                for my $split_access ( split '', $access ) {
                    $profile{$profilename}{$victim_file}{$split_access} = 1;
                }
            }
        };
    }
};

if ($grouping) {
    if ($testing) {
        for my $key ( keys %profile ) {
            my %foo = %{ $profile{$key} };
            for my $entry ( keys %{ $profile{$key} } ) {
                my $regex        = $entry;
                my @entry_attrib = ( keys %{ $profile{$key}{$entry} } );
                $regex =~ s/(?<!\*)\*(?! (\*|$))/.*?/g;
                $regex =~ s:(?<!\*)\*(?!\*):(?!.*/).*:g;
                $regex =~ s/\*{2,2}/.*/g;

                map {
                    my $delete  = "no";
                    my $tempvar = $_;
                    map { $delete = "yes" if $profile{$key}{$tempvar}{$_} }
                      @entry_attrib;
                    delete( $foo{$_} )
                      if m:^$regex: && $entry ne $_ && $delete eq "yes";
                  }
                  keys %foo;
            }
            map { delete( $profile{$key}{$_} ) if !$foo{$_}; }
              keys %{ $profile{$key} };
        }
    }
    my %directory;
    for my $key ( keys %profile ) {
        for ( keys %{ $profile{$key} } ) {
            my @foo = split '/', $_;
            my $file = pop (@foo);
            my $dir = join '/', @foo;
            my $attributes = join '', ( sort keys %{ $profile{$key}{$_} } );
            push ( @{ $directory{$key}{$dir}{$attributes} }, $file );
        }
    }
    for my $key ( keys %directory ) {
        if ($splitting) {
            ( my $split_file = join '.', ( split '/', $key ) ) =~ s:^.::g;
            open( NEW, "> $split_file" );
        }
        else {
            open( NEW, ">&STDOUT" );
        }
        print NEW "$key {\n";
        for my $dir ( keys %{ $directory{$key} } ) {
            for my $attributes ( keys %{ $directory{$key}{$dir} } ) {
                my $files;
                if ( scalar( @{ $directory{$key}{$dir}{$attributes} } ) > 1 ) {

 #                    $files = '{'
 #                      . join ( ',', @{ $directory{$key}{$dir}{$attributes} } )
 #                      . '}';
                    for
                      my $tempfile ( @{ $directory{$key}{$dir}{$attributes} } )
                    {
                        if ( length( $dir . $files . $tempfile ) > 68 ) {
                            print NEW "$dir/{$files} $attributes\n";
                            $files = $tempfile;
                        }
                        else {
                            ( $files = join ( ',', $files, $tempfile ) ) =~
                              s:^,::g;
                        }
                    }
                    $files = '{' . $files . '}';
                }
                else {
                    $files = @{ $directory{$key}{$dir}{$attributes} }[0];
                }
                print NEW "$dir/$files $attributes,\n";
            }
        }
        print NEW "}\n";
        close(NEW);
    }

}
else {
    for my $key ( keys %profile ) {
        if ($splitting) {
	  ( my $split_file = join '.', ( split '/', $key ) ) =~ s:^.::g;
	  open( NEW, "> $split_file" );
        }
        else {
            open( NEW, ">&STDOUT" );
        }
        print NEW "$key {\n";
        for my $second ( sort keys %{ $profile{$key} } ) {
            print NEW "$second ";
            for my $third ( sort keys %{ $profile{$key}{$second} } ) {
                print NEW "$third";
            }
            print NEW ",\n";
        }
        print NEW "}\n";
        close NEW;
    }
}

sub use_old {
    my @files = <$olddir/*>;
    my ($profilename);
    for my $file (@files) {
      my $firstline = 1;
        next if !-f $_;
        open( FILE, $file ) || ( carp "Couldn't open file: $file -- $!\n" && next );
        while (<FILE>) {
	  last && carp "Not a valid subdomain profile." if $firstline == 1 && $_ !~ /\{$/;
            chomp;
            my @line = split '\s+', $_;
            next if scalar(@line) < 1;
            next
              if $line[0] eq "}"
              || $line[0] =~ /^\#/;
            if ( $line[1] eq '{' ) {
                $profilename = $line[0];
                next;
            }
            if ( $line[0] =~ /\{.*\}/ ) {
                for my $foo ( iterate( $line[0] ) ) {
                    for my $tmp ( split '', $line[1] ) {
                        next if $tmp eq ',';
                        $profile{$profilename}{$foo}{$tmp} = 1;
                    }
                }

            }
            else {
                for my $tmp ( split '', $line[1] ) {
                    next if $tmp eq ',';
                    $profile{$profilename}{ $line[0] }{$tmp} = 1;
                }
            }

        }
        close FILE;
    }
}

sub iterate {
    my @output;
    for (@_) {
        my $line = $_;

        return $line if $line !~ /\{.*\}/;
        my ( $base, $group, $rest ) = ( $line =~ /(.*?)\{(.*?)\}(.*)/ );
        for my $foo ( split ',', $group ) {
            for ( iterate( $base . $foo . $rest ) ) {
                push ( @output, $_ );
            }
        }
    }
    return @output;
}

#!/bin/sh
#
# $Id: update_profiles.sh 4425 2005-05-03 22:37:48Z sarnold $
#
# ----------------------------------------------------------------------
#    PROPRIETARY DATA of IMMUNIX INC.
#    Copyright (c) 2004, IMMUNIX (All rights reserved)
#
#    This document contains trade secret data which is the property
#    of IMMUNIX Inc.  This document is submitted to recipient in
#    confidence. Information contained herein may not be used, copied
#    or disclosed in whole or in part except as permitted by written
#    agreement signed by an officer of IMMUNIX, Inc.
# ----------------------------------------------------------------------
#
# do the profile update crank dance

#
# Where are the profile utilities extracted to.
#
BINDIR=/root/bin

cat /etc/subdomain.d/* > /tmp/massive
cp /var/log/messages /tmp/
cat /tmp/messages | $BINDIR/sdprof -b -w /tmp/massive > /tmp/profiles.new
cd /etc/subdomain.d/
tar zcf  /profiles_`date +%Y%m%d%H%M`.tar.gz *
rm -f * 
if [ -d "/profiles" ]; then
  #echo "profiles directory found"
  echo ""
else
  mkdir /profiles
fi

cd /profiles
rm -f *
cp /tmp/profiles.new .
cp $BINDIR/grind .
./grind profiles.new >& /dev/null
rm -f grind profiles.new
cp * /etc/subdomain.d/
$BINDIR/rotate_messages.pl >& /dev/null
/etc/init.d/subdomain restart


//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by C:\work\pismere\athena\auth\krb5\src\windows\identity\plugins\krb4\lang\en_us\langres.rc
//
#define IDS_UNK_ADDR_FMT                101
#define IDS_KRB5_CREDTEXT_0             102
#define IDD_NC_KRB4                     103
#define IDS_PLUGIN_DESC                 103
#define IDS_KEY_ENCTYPE_SHORT_DESC      104
#define IDD_CFG_KRB4                    104
#define IDS_NC_K4_SHORT                 104
#define IDS_TKT_ENCTYPE_SHORT_DESC      105
#define IDS_ERR_REALM                   105
#define IDD_CFG_IDS_KRB4                105
#define IDS_KEY_ENCTYPE_LONG_DESC       106
#define IDS_ERR_PRINCIPAL               106
#define IDD_CFG_ID_KRB4                 106
#define IDS_TKT_ENCTYPE_LONG_DESC       107
#define IDS_ERR_INVINST                 107
#define IDI_ICON1                       107
#define IDI_PLUGIN                      107
#define IDS_ADDR_LIST_SHORT_DESC        108
#define IDS_ERR_PWINTKT                 108
#define IDS_ADDR_LIST_LONG_DESC         109
#define IDS_CT_DISABLED                 109
#define IDS_ETYPE_NULL                  110
#define IDS_CT_TGTFOR                   110
#define IDS_ETYPE_DES_CBC_CRC           111
#define IDS_METHOD_AUTO                 111
#define IDS_ETYPE_DES_CBC_MD4           112
#define IDS_METHOD_PWD                  112
#define IDS_ETYPE_DES_CBC_MD5           113
#define IDS_METHOD_K524                 113
#define IDS_ETYPE_DES_CBC_RAW           114
#define IDS_CFG_IDS_KRB4_SHORT          114
#define IDS_ETYPE_DES3_CBC_SHA          115
#define IDS_ETYPE_DES3_CBC_RAW          116
#define IDS_ETYPE_DES_HMAC_SHA1         117
#define IDS_ETYPE_DES3_CBC_SHA1         118
#define IDS_ETYPE_AES128_CTS_HMAC_SHA1_96 119
#define IDS_ETYPE_AES256_CTS_HMAC_SHA1_96 120
#define IDS_ETYPE_ARCFOUR_HMAC          121
#define IDS_ETYPE_ARCFOUR_HMAC_EXP      122
#define IDS_ETYPE_UNKNOWN               123
#define IDS_ETYPE_LOCAL_DES3_HMAC_SHA1  124
#define IDS_ETYPE_LOCAL_RC4_MD4         125
#define IDS_KRB5_SHORT_DESC             126
#define IDS_KRB5_LONG_DESC              127
#define IDS_KRB4_SHORT_DESC             128
#define IDS_KRB4_LONG_DESC              129
#define IDS_KRB5_FLAGS_SHORT_DESC       130
#define IDS_RENEW_TILL_SHORT_DESC       131
#define IDS_RENEW_TILL_LONG_DESC        132
#define IDS_RENEW_FOR_SHORT_DESC        133
#define IDS_RENEW_FOR_LONG_DESC         134
#define IDS_CFG_KRB4_LONG               135
#define IDS_CFG_KRB4_SHORT              136
#define IDC_NCK5_RENEWABLE              1002
#define IDC_NCK5_FORWARDABLE            1004
#define IDC_NCK5_REALM                  1005
#define IDC_NCK5_ADD_REALMS             1006
#define IDC_NCK5_LIFETIME_EDIT          1008
#define IDC_NCK5_RENEW_EDIT             1009
#define IDC_PPK5_CRENEW                 1014
#define IDC_PPK5_CFORWARD               1015
#define IDC_PPK5_CPROXY                 1016
#define IDC_PPK5_NAME                   1017
#define IDC_PPK5_ISSUE                  1018
#define IDC_PPK5_VALID                  1019
#define IDC_PPK5_RENEW                  1020
#define IDC_CHECK2                      1022
#define IDC_CHECK4                      1024
#define IDC_PPK5_LIFETIME               1024
#define IDC_CHECK5                      1025
#define IDC_CFG_LBL_CACHE               1025
#define IDC_CFG_LBL_CFGFILE             1026
#define IDC_CFG_LBL_RLMPATH             1027
#define IDC_CFG_CACHE                   1028
#define IDC_CFG_CFGPATH                 1029
#define IDC_CFG_RLMPATH                 1030
#define IDC_CFG_CFGBROW                 1031
#define IDC_CFG_RLMBROW                 1032
#define IDC_NCK4_OBTAIN                 1033
#define IDC_NCK4_PWD                    1034
#define IDC_NCK4_K524                   1035
#define IDC_NCK4_AUTO                   1036
#define IDC_CFG_GETTIX                  1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

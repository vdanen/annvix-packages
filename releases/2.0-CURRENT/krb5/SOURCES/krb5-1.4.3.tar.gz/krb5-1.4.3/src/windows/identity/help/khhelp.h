
#define IDH_WELCOME                1000
#define IDH_MENU_FILE              1001
#define IDH_MENU_CRED              1002
#define IDH_MENU_VIEW              1003
#define IDH_MENU_OPTIONS           1004
#define IDH_MENU_HELP              1005

#define IDH_ACTION_PROPERTIES      2000
#define IDH_ACTION_EXIT            2001
#define IDH_ACTION_NEW_ID          2002
#define IDH_ACTION_SET_DEF_ID      2003
#define IDH_ACTION_SET_SRCH_ID     2004
#define IDH_ACTION_DESTROY_ID      2005
#define IDH_ACTION_RENEW_ID        2006
#define IDH_ACTION_PASSWD_ID       2007
#define IDH_ACTION_NEW_CRED        2008
#define IDH_ACTION_CHOOSE_COLS     2009
#define IDH_ACTION_DEBUG_WINDOW    2010
#define IDH_ACTION_VIEW_REFRESH    2011
#define IDH_ACTION_OPT_KHIM        2012
#define IDH_ACTION_OPT_INIT        2013
#define IDH_ACTION_OPT_NOTIF       2014

#ifndef _KUDZU_PCISERIAL_H_
#define _KUDZU_PCISERIAL_H_

#include <pci/pci.h>

#include "pci.h"

extern void checkPCISerial (struct pciDevice *, struct pci_dev *);

#endif /* _KUDZU_PCISERIAL_H_ */

#####################################################################################################
#
# Small script descriptions
#
# NOTE: these scripts are submitted and can have their own license. Please check the source
#       of each file to see how you can use this software.
#
#####################################################################################################

[script]		[description]
run_rkhunter		Start rkhunter

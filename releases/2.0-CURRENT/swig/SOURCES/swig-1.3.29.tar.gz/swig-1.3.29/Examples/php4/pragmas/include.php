<?php

# This code is inserted into example.php
echo "this is hi.php\n";


?>

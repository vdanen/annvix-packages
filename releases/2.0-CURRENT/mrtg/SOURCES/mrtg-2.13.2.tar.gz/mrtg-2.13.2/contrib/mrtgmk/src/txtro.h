#ifndef _TXT_H_
#define _TXT_H_

char* etxt[]={
    "de",
    "obligatoriu",
    "optional",
    "fisierul pt. configurare"
    };

char* btxt[]={
    "Analiza trafic",	
    "Analiza traficului pentru",
    ".gifs pentru hosturile definite in fisierul"
    };

char* err[]={
    "\aERROR: deschidere fisier %s\n",
    "\aERROR: fisierul index %s are lungime 0 si il sterg\n",
    "\aERROR: nu a fost definit un fisier mrtg.cfg\n",
    "\aERROR: portul %s lipseste din %s/%s\n",
    "\aERROR: portul %s lipseste din %s\n",
    "\aERROR: fisierul de configurare %s lipseste\n",
    "\aERROR: hostul %s redefinit\n",
    "\aERROR: alias %s redefinit\n",
    "\aERROR: nu a fost definit nici un alias %s\n",
    "\aERROR: nu a fost definit nici un host %s\n",
    "\aERROR: nu ma pot muta in directorul %s\n",	//10
    "\aERROR: argumentul pentru CHECK4ALIAS a fost %s",
    "\aERROR: argumentul pentru CHNGTRGNAME a fost %s"
    };
    
#endif
    
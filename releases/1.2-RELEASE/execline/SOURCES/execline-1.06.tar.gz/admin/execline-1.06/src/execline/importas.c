#include "exls1.h"

char const *PROG = "importas" ;
#define USAGE "importas [ -D default ] [ -n ] [ -s ] [ -C | -c ] [ -d delim ] key envvar prog..."

int main (int argc, char const **argv, char const *const *envp)
{
  exls1_main(argc, argv, envp, &exls1_importas, USAGE) ;
}

#include "exls1.h"

char const *PROG = "import" ;
#define USAGE "import [ -D default ] [ -n ] [ -s ] [ -C | -c ] [ -d delim ] envvar prog..."

int main (int argc, char const **argv, char const *const *envp)
{
  exls1_main(argc, argv, envp, &exls1_import, USAGE) ;
}

#ifndef EXLP_H
#define EXLP_H

#include "stralloc.h"
#include "uintalloc.h"
#include "gen_alloc.h"
#include "execline.h"

GEN_ALLOC_PROTOTYPES(substalloc, elsubst, s, len, a)

extern unsigned int exlp (unsigned int, char const *const *, stralloc *, stralloc *, uintalloc *) ;

#endif

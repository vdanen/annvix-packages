/* Public domain. */

#include <unistd.h>
#include <sys/types.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/un.h>
#include "djbunix.h"
#include "pflocal.h"
#include "webipc.h"

int ipc_datagram ()
{
  int s = socket(PF_LOCAL, SOCK_DGRAM, 0) ;
  if (s == -1) return -1 ;
  if (ndelay_on(s) == -1) { fd_close(s) ; return -1 ; }
  return s ;
}

/* Public domain. */

#ifndef ALLOC_0_H
#define ALLOC_0_H

#include "sysdeps.h"

#ifndef HASMALLOC0

#include "alloc.h"

extern aligned_char_ref alloc_0 ;

#endif

#endif

/* Public domain. */

/* MT-unsafe */

#include "random.h"

int goodrandom_init (void)
{
  return 1 ;
}

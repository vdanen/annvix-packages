/* Public domain. */

#include "stralloc.h"
#include "envalloc.h"
#include "djbunix.h"

void pathexec_r_tmp_envtmp (char const *const *argv, char const *const *envp, unsigned int envlen, char const *modifs, unsigned int modiflen, stralloc *tmp, envalloc *v)
{
  unsigned int vbase = v->len ;
  if (envalloc_merge(v, envp, envlen, modifs, modiflen) && envalloc_0(v))
    pathexec_run_tmp(argv[0], argv, v->s + vbase, tmp) ;
  v->len = vbase ;
}

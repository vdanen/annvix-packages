/* Public domain. */

#ifndef DIUINTBUNCH_H
#define DIUINTBUNCH_H

#include "diuint.h"
#include "diuintalloc.h"
#include "gen_bunch.h"

GEN_BUNCH_PROTOTYPES(diuintbunch, diuintalloc, diuint)

#endif

/* Public domain. */

#ifndef PFLOCAL_H
#define PFLOCAL_H

#ifndef PF_LOCAL
#define PF_LOCAL PF_UNIX
#endif

#endif

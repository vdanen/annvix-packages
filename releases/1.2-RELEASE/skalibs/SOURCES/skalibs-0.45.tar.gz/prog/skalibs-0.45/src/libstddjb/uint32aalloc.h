/* Public domain. */

#ifndef UINT32AALLOC_H
#define UINT32AALLOC_H

#include "uint32alloc.h"

GEN_ALLOC_PROTOTYPES(uint32aalloc, uint32alloc, s, len, a)

#endif

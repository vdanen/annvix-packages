/* Public domain. */

#include <limits.h>
#include "fmtscan.h"
#include "fmtscan-internal.h"

SCANU0(uint, unsigned int, UINT_MAX)

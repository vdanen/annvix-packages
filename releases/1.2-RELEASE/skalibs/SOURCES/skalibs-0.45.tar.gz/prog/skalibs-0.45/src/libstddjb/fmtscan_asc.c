/* Public domain. */

#include "fmtscan.h"

unsigned char fmtscan_asc (unsigned char c)
{
  unsigned char const tab[36] = "0123456789abcdefghijklmnopqrstuvwxyz" ;
  return (c >= 36) ? 0 : tab[c] ;
}

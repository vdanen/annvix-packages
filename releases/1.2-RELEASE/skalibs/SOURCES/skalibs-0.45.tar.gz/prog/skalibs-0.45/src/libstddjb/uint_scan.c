/* Public domain. */

#include <limits.h>
#include "fmtscan.h"
#include "fmtscan-internal.h"

SCANU(uint, unsigned int, UINT_MAX)

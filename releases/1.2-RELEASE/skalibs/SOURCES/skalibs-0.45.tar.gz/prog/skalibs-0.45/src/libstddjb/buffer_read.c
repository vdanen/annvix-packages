/* Public domain. */

#include "allreadwrite.h"
#include "buffer.h"

int buffer_unixread (int fd, char *buf, unsigned int len)
{
  return fd_read(fd, buf, len) ;
}

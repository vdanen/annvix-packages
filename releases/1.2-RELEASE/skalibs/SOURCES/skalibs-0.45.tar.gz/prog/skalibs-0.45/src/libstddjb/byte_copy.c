/* Public domain. */

#include "bytestr.h"

#ifdef USE_BASE_LIBC

#include <string.h>

void byte_copy (register char *to, register unsigned int n, register char const *from)
{
  memmove(to, from, n) ;
}

#else

void byte_copy (register char *to, register unsigned int n, register char const *from)
{
  while (n--) *to++ = *from++ ;
}

#endif

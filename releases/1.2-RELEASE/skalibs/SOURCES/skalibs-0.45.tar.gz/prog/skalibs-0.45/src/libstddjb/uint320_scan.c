/* Public domain. */

#include "uint32.h"
#include "uint64.h"
#include "fmtscan-internal.h"

SCANU0(uint32, uint32, ((uint64)1 << 32) - 1)

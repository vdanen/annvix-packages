/* Public domain. */

#include "gen_alloc.h"
#include "diuint.h"
#include "diuintalloc.h"

GEN_ALLOC_EXTENDED_DEFS(diuintalloc, diuint, s, len, a)

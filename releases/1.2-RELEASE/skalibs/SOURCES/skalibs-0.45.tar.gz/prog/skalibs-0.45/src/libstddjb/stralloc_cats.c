/* Public domain. */

#include "bytestr.h"
#include "stralloc.h"

int stralloc_cats (stralloc *sa, char const *s)
{
  return stralloc_catb(sa, s, str_len(s)) ;
}

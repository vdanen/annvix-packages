/* Public domain. */

/* MT-unsafe */

#include "buffer.h"

static char buf[BUFFER_INSIZE_SMALL] ;
static buffer b = BUFFER_INIT(&buffer_unixread, 0, buf, BUFFER_INSIZE_SMALL) ;
buffer_ref buffer_0small = &b ;

/* Public domain. */

/* MT-unsafe */

#include "skamisc.h"
#include "djbunix.h"

void pathexec_run (char const *file, char const *const *argv, char const *const *envp)
{
  pathexec_run_tmp(file, argv, envp, &satmp) ;
}

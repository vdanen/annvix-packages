/* Public domain. */

/* MT-unsafe */

#include "dns_transmit.h"

struct dns_rcrw_info dns_rcrw_info_here = DNS_RCRW_INFO_ZERO ;

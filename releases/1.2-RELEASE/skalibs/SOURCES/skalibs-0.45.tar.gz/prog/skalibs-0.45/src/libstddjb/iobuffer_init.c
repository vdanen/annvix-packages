/* Public domain. */

#include "buffer.h"
#include "iobuffer.h"

void iobuffer_init (iobuffer_ref b, int fdin, int fdout, char *x, unsigned int len)
{
  buffer_init(&b->in, &buffer_unixread, fdin, x, len) ;
  buffer_init(&b->out, &buffer_unixwrite, fdout, x, len) ;
}

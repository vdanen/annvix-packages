/* Public domain. */

#include "dns_helper.h"

unsigned int dns_domain_suffixpos(char const *big, char const *little)
{
  char const *orig = big ;
  for (;;)
  {
    unsigned char c ;
    if (dns_domain_equal(big, little)) return big - orig ;
    c = *big++ ;
    if (!c) return 0 ;
    big += c ;
  }
}

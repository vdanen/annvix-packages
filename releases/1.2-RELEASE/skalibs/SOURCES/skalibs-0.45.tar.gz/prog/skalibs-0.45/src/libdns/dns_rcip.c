/* Public domain. */

/* MT-unsafe */

#include "bytestr.h"
#include "dns_transmit.h"

int dns_resolvconfip (char *s)
{
  if (!dns_resolvconfipit(&dns_rcip_info_here)) return -1 ;
  byte_copy(s, 64, dns_rcip_info_here.ip) ;
  return 0 ;
}

/* Public domain. */

#include <limits.h>
#include "fmtscan.h"
#include "fmtscan-internal.h"

SCANU(ushort, unsigned short, USHRT_MAX)

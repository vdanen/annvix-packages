/* Public domain. */

#ifndef BUFFER_INTERNAL_H
#define BUFFER_INTERNAL_H

#include "allreadwrite.h"
#include "buffer.h"

#define buffer_fullop(b, buf, len) allreadwrite((b)->op, (b)->fd, (buf), (len))

#endif

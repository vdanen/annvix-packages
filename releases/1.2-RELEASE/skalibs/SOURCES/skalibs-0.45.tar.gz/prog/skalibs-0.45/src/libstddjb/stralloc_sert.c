/* Public domain. */

#include "stralloc.h"

int stralloc_insert (stralloc *to, unsigned int offset, stralloc const *from)
{
  return stralloc_insertb(to, offset, from->s, from->len) ;
}

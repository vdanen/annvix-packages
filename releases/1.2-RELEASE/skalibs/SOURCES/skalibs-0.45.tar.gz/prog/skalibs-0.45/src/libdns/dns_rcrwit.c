/* Public domain. */

#include "skamisc.h"
#include "dns_transmit.h"

int dns_resolvconfrewriteit (struct dns_rcrw_info *dr)
{
  return dns_resolvconfrewriteit_tmp(dr, &satmp) ;
}

/* Public domain. */

#ifndef STDCRYPTO_H
#define STDCRYPTO_H

#include "rc4.h"
#include "md5.h"
#include "sha1.h"

#endif

/* Public domain. */

#undef USE_DJBALLOC
#include "gen_alloc.h"
#include "stralloc.h"

GEN_ALLOC_BASE_DEFS(stralloc, char, s, len, a, 256)

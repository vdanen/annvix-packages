/* Public domain. */

#include "gen_alloc.h"
#include "stralloc.h"
#include "envalloc.h"
#include "djbunix.h"

void pathexec_r_tmp (char const *const *argv, char const *const *envp, unsigned int envlen, char const *modifs, unsigned int modiflen, stralloc *tmp)
{
  envalloc v = GEN_ALLOC_ZERO ;
  pathexec_r_tmp_envtmp(argv, envp, envlen, modifs, modiflen, tmp, &v) ;
  envalloc_free(&v) ;
}

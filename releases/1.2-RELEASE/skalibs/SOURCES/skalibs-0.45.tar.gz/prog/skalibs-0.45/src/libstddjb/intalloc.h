/* Public domain. */

#ifndef INTALLOC_H
#define INTALLOC_H

#include "gen_alloc.h"

GEN_ALLOC_PROTOTYPES(intalloc, int, s, len, a)

#endif

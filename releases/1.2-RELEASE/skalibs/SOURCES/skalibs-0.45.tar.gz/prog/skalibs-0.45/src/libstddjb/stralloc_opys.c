/* Public domain. */

#include "bytestr.h"
#include "stralloc.h"

int stralloc_copys (stralloc *sa, char const *s)
{
  return stralloc_copyb(sa, s, str_len(s)) ;
}

/* Public domain. */

#include "surf.h"

void surf_init (SURFSchedule_ref ctx)
{
  unsigned char s[160] ;
  surf_makeseed(s) ;
  surf_sinit(ctx, s) ;
}

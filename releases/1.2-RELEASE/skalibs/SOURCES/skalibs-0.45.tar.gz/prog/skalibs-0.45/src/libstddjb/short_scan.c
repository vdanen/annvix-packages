/* Public domain. */

#include "fmtscan.h"

unsigned int short_scan (char const *s, short *n)
{
  if ((*s == '-') || (*s == '+'))
  {
    unsigned short tmp ;
    register unsigned int r = ushort_scan(s+1, &tmp) ;
    if (!r) return 0 ;
    *n = (*s == '-') ? -tmp : tmp ;
    return r + 1 ;
  }
  return ushort_scan(s, n) ;
}

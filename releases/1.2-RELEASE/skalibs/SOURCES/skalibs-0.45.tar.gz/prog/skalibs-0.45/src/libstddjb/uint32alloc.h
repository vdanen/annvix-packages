/* Public domain. */

#ifndef UINT32ALLOC_H
#define UINT32ALLOC_H

#include "uint32.h"
#include "gen_alloc.h"

GEN_ALLOC_PROTOTYPES(uint32alloc, uint32, s, len, a)

#endif

/* Public domain. */

#ifndef GETPEEREID_H
#define GETPEEREID_H

extern int getpeereid (int, int *, int *) ;

#endif

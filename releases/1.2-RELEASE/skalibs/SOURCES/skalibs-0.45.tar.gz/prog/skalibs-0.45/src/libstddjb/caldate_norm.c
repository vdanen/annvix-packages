/* Public domain. */

#include "caltimedate.h"

void caldate_normalize (struct caldate *cd)
{
  caldate_frommjd(cd, caldate_mjd(cd), 0, 0) ;
}

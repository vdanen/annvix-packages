/* Public domain. */

/* MT-unsafe */

#include "buffer.h"

static char buf[BUFFER_ERRSIZE] ;
static buffer b = BUFFER_INIT(&buffer_unixwrite, 2, buf, BUFFER_ERRSIZE) ;
buffer_ref buffer_2 = &b ;

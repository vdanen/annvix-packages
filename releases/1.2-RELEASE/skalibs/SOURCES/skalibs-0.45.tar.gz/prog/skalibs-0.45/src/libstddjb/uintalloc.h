/* Public domain. */

#ifndef UINTALLOC_H
#define UINTALLOC_H

#include "gen_alloc.h"

GEN_ALLOC_PROTOTYPES(uintalloc, unsigned int, s, len, a)

#endif

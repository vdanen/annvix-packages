/* Public domain. */

#include "buffer.h"
#include "iobuffer.h"

int iobuffer_fill (iobuffer_ref b)
{
  register int r = buffer_fill(&b->in) ;
  b->out.n = b->in.n ;
  b->out.p = b->in.p ;
  return r ;
}

int iobuffer_flush (iobuffer_ref b)
{
  register int r = buffer_flush(&b->out) ;
  b->in.n = b->out.n ;
  b->in.p = b->out.p ;
  return r ;
}

/* Public domain. */

/* MT-unsafe */

#include "stralloc.h"
#include "dns.h"

int dns_txt (stralloc *out, stralloc const *fqdn)
{
  char *q = 0 ;
  register int r ;
  if (!dns_domain_fromdot(&q, fqdn->s, fqdn->len)) return -1 ;
  if (dns_resolve(q, DNS_T_TXT) == -1)
  {
    dns_domain_free(&q) ;
    return -1 ;
  }
  r = dns_txt_packet(out, dns_resolve_tx.packet, dns_resolve_tx.packetlen) ;
  dns_transmit_free(&dns_resolve_tx);
  dns_domain_free(&q) ;
  return r ;
}

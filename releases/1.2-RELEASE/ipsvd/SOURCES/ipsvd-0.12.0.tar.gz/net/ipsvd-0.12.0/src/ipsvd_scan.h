#ifndef IPSVD_SCAN_H
#define IPSVD_SCAN_H

extern unsigned int ipsvd_scan_port(const char *s, const char *proto,
				    unsigned long *p);

#endif

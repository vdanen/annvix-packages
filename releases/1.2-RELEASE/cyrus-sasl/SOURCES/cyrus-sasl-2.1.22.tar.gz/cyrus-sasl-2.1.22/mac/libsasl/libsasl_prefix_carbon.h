/*
 * compile the plugins into the library for nice debugging
 */

#define NO_SASL_MONOLITHIC

/*
 * compiler doesnt allow an empty file
 */
typedef int xxx_sc_foo;

#define TARGET_API_MAC_CARBON 1

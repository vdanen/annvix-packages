/*
 * (C) 2001 Uwe Ohse, <uwe@ohse.de>.
 * Placed in the public domain.
 */
/* @(#) $Id: get_cwd.h 1.3 01/05/03 06:31:32+00:00 uwe@fjoras.ohse.de $ */
char * get_cwd(void);


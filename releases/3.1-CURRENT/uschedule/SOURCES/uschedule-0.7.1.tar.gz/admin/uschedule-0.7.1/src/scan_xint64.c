/*
 * placed in the public domain by Uwe Ohse, uwe@ohse.de.
 */
#include "gen_scan.h"
#include "uint64.h"

SCAN_UFUNC(xint64, uint64,16,"0123456789abcdef")

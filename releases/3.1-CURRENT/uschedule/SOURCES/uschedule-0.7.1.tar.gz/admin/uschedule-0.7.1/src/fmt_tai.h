#include "tai.h"
int fmt_tai(char *buf, unsigned int size, struct tai *t);

#include "uint32.h"
/* my shell sort */
extern void mssort (char *base, uint32 n, uint32 elesize,
		  int (*fn) (const void *, const void *));


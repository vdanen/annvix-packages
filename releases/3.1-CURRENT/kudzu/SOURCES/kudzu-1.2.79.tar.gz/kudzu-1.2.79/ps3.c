/* Copyright 2005 Red Hat, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 * 
 */

#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/fd.h>

#include "ps3.h"
#include "kudzuint.h"
#include "modules.h"

struct ps3_device_type {
	int type;
	const char *driver;
	const char *desc;
};

static struct ps3_device_type ps3_device_types[] = {
	[1] = { CLASS_USB, "ehci-hcd", "PlayStation 3 EHCI" },
	[2] = { CLASS_USB, "ohci-hcd", "PlayStation 3 OHCI" },
	[3] = { CLASS_NETWORK, "ps3_gelic", "PlayStation 3 Gigabit Ethernet" },
/*	[4] = { CLASS_OTHER, "ps3av_mod", "PlayStation 3 AV Settings" }, */
/*	[5] = { CLASS_OTHER, "sys-manager", "PlayStation 3 System Manager" }, */
	[6] = { CLASS_HD, "ps3disk", "PlayStation 3 internal disk" },
	[7] = { CLASS_SCSI, "ps3rom", "PlayStation 3 Blu-ray drive" },
	[8] = { CLASS_OTHER, "ps3flash", "PlayStation 3 OtherOS flash storage" },
	[9] = { CLASS_AUDIO, "snd_ps3", "PlayStation 3 audio" },
	[10] = { CLASS_VIDEO, "ps3fb", "PlayStation 3 framebuffer" },
};
#define nr_ps3_devtypes ( sizeof(ps3_device_types) / sizeof(ps3_device_types[0]) )


static void ps3FreeDevice(struct ps3Device *dev)
{
	freeDevice((struct device *) dev);
}

static void ps3WriteDevice(FILE *file, struct ps3Device *dev)
{
	writeDevice(file, (struct device *)dev);
}

static int ps3CompareDevice(struct ps3Device *dev1, struct ps3Device *dev2)
{
	return compareDevice( (struct device *)dev1, (struct device *)dev2);
}

struct ps3Device *ps3NewDevice(struct ps3Device *old)
{
	struct ps3Device *ret;

	ret = malloc(sizeof(struct ps3Device));
	memset(ret, '\0', sizeof(struct ps3Device));
	ret = (struct ps3Device *) newDevice((struct device *) old, (struct device *) ret);
	ret->bus = BUS_PS3;
	ret->newDevice = ps3NewDevice;
	ret->freeDevice = ps3FreeDevice;
	ret->writeDevice = ps3WriteDevice;
	ret->compareDevice = ps3CompareDevice;
	return ret;
}

struct device *ps3Probe(enum deviceClass probeClass, int probeFlags,
			struct device *devlist)
{
#ifdef __powerpc__
	struct ps3Device *ps3dev;
	DIR * dir;
	struct dirent * ent;
	int new_storage = 0;

	if (access("/sys/bus/ps3_system_bus/devices", R_OK)) 
		return devlist;

	dir = opendir("/sys/bus/ps3_system_bus/devices");
	while ((ent = readdir(dir))) {
		char path[64];
		int fd;
		char alias[16];
		char *end;
		int match_id;

		snprintf(path, 64, "/sys/bus/ps3_system_bus/devices/%s/modalias", ent->d_name);

		fd = open(path, O_RDONLY);
		if (fd < 0)
			continue;
		memset(alias, 0, 16);
		if (read(fd, alias, 15) <= 0) {
			close(fd);
			continue;
		}
		close(fd);
		if (strncmp(alias, "ps3:", 4))
			continue;
		match_id = strtol(alias+4, &end, 10);
		if (end == alias+4 || *end != '\n')
			continue;
		if (match_id < 1 || match_id >= nr_ps3_devtypes)
			continue;

		if (probeClass & ps3_device_types[match_id].type) {
			ps3dev = ps3NewDevice(NULL);
			ps3dev->type = ps3_device_types[match_id].type;
			ps3dev->desc = strdup(ps3_device_types[match_id].desc);
			if (ps3_device_types[match_id].driver)
				ps3dev->driver = strdup(ps3_device_types[match_id].driver);
			else {
				*end = '\0';
				ps3dev->driver = strdup(alias);
			}
			/* Back to the sysfs directory */
			*(strrchr(path,'/')) = '\0';

			/* Special cases */
			switch (ps3dev->type) {
			case CLASS_NETWORK: /* gelic_net */
				__getSysfsDevice((struct device *)ps3dev, path, "net:",0);
				if (ps3dev->device)
					__getNetworkAddr((struct device *)ps3dev, ps3dev->device);
				else
					ps3dev->device = strdup("eth");
				break;
			case CLASS_VIDEO: /* ps3fb */
				ps3dev->classprivate = (void *)strdup("fbdev");
				break;
			case CLASS_SCSI:
				new_storage = 1;
				break;
			case CLASS_HD:
				__getSysfsDevice((struct device *)ps3dev, path, "block:", 0);
				break;
			case CLASS_OTHER:
				__getSysfsDevice((struct device *)ps3dev, path, "misc:", 0);
				break;
			default:
				;
			}

			if (devlist)
				ps3dev->next = devlist;
			devlist = (struct device *) ps3dev;
		}
	}
	closedir(dir);

	/* Doesn't match new ps3fb device, but the above does */
	if (probeClass & CLASS_VIDEO) {
		char path[64];
		int i;
		char *name;

		for (i = 0; ; i++) {
			snprintf(path,64,"/sys/class/graphics/fb%d/name",i);
			name = __readString(path);
			if (!name)
				break;
			if (!strcmp(name, "PS3 FB")) {
				ps3dev = ps3NewDevice(NULL);
				ps3dev->desc = strdup("PlayStation 3 Framebuffer");
				ps3dev->type = CLASS_VIDEO;
				ps3dev->driver = strdup("ps3fb");
				ps3dev->classprivate = (void *)strdup("fbdev");
				if (devlist)
					ps3dev->next = devlist;
				devlist = (struct device *) ps3dev;
			}
		}
	}

	/* Legacy SCSI-based PS3 storage; not if the new ps3_system_bus version is present */
	if (probeClass & CLASS_SCSI && !new_storage) {
		char model[16];
		int fd = open("/proc/device-tree/model", O_RDONLY);
		if (fd >= 0) {
			if (read(fd, model, 16) == 14 && !strncmp(model, "PLAYSTATION 3", 13)) {
				ps3dev = ps3NewDevice(NULL);
				ps3dev->desc = strdup("PlayStation 3 storage");
				ps3dev->driver = strdup("ps3_storage");
				ps3dev->type = CLASS_SCSI;
				if (devlist)
					ps3dev->next = devlist;
				devlist = (struct device *) ps3dev;
			}
			close(fd);
		}
	}
#endif
	return devlist;
}

#ifndef	_ANTLR3_ENCODINGS_H
#define	_ANTLR3_ENCODINGS_H

#include <antlr3defs.h>



#endif


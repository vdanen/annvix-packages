#ifndef PREFERENCES_DIALOG_H
#define PREFERENCES_DIALOG_H

GtkWidget* create_preferences_dialog (void);
void button_press (GtkDialog * dialog, gint answer, gpointer data);

#endif



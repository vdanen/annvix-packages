
/*
 *
 * passwd wrapper - implements traditional passwd options using
 * real passwd utility or shadow utils.
 *
 * Copyright (C) 2002, 2004, 2005  Dmitry V. Levin <ldv@altlinux.org>
 *
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <errno.h>
#include <argp.h>
#include <pwd.h>
#include <shadow.h>

static void
__attribute__ ((__noreturn__, __format__ (__printf__, 2, 3)))
failure (int errnum, const char *fmt, ...)
{
	va_list args;

	fflush (stdout);
	fprintf (stderr, "%s: ", program_invocation_short_name);
	va_start (args, fmt);
	vfprintf (stderr, fmt, args);
	va_end (args);
	if (errnum)
		fprintf (stderr, ": %s", strerror (errnum));
	putc ('\n', stderr);
	fflush (stderr);

	exit (EXIT_FAILURE);
}

static void
__attribute__ ((__noreturn__))
fail_username (void)
{
	fprintf (stderr,
		 "%s: this operation requires username to be specified.\n",
		 program_invocation_short_name);

	exit (EXIT_FAILURE);
}

#define OPT_STDIN 0x13

const char *argp_program_version = "passwd wrapper version " PROJECT_VERSION;

const char *argp_program_bug_address = "http://bugs.altlinux.ru/";

/* Short description of program.  */
static const char doc[] =
	"passwd wrapper implements traditional passwd options using real passwd utility or shadow utils.";

/* Strings for arguments in help texts.  */
static const char args_doc[] = "[USERNAME]";

/* The options we understand. */
static struct argp_option options[] = {
	{0, 0, 0, 0, "Valid options are:", 0},
	{"delete", 'd', 0, 0, "Delete the password for the specified account", 0},
	{"force", 'f', 0, 0, "Force operation", 0},
	{"keep-tokens", 'k', 0, 0, "Keep non-expired authentication tokens", 0},
	{"lock", 'l', 0, 0, "Lock the specified account", 0},
	{"unlock", 'u', 0, 0, "Unlock the specified account", 0},
	{"status", 'S', 0, 0, "Report password status on the specified account", 0},
	{"stdin", OPT_STDIN, 0, 0, "Read new tokens from stdin", 1},
	{0, 0, 0, 0, 0, 0}
};

typedef int (*DO_FPTR) (void);
DO_FPTR do_fun;

static int is_keep;
const char *username;

static int
chpasswd (const char *passwd)
{
	FILE   *fp;
	const char *path = "/usr/sbin/chpasswd";

	if (!username)
		fail_username ();

	fp = popen (path, "w");
	if (!fp)
		failure (errno, "popen: %s", path);

	if (fprintf (fp, "%s:%s\n", username, passwd) !=
	    (int)(2 + strlen (username) + strlen (passwd)))
		failure (errno, "fprintf");

	if (pclose (fp) < 0)
		failure (errno, "pclose");

	return EXIT_SUCCESS;
}

static int
do_stdin (void)
{
	size_t  len;
	char    buf[BUFSIZ];

	if (!username)
		fail_username ();

	if (!fgets (buf, sizeof (buf), stdin))
		failure (errno, "error reading password");

	len = strlen (buf);
	if (len > 0 && ('\n' == buf[len - 1]))
		buf[len - 1] = '\0';

	return chpasswd (buf);
}

static int
do_delete (void)
{
	return chpasswd ("");
}

static void
__attribute__ ((__noreturn__))
lock_unlock (const char *param)
{
	const char *path = "/usr/sbin/usermod";
	size_t  argc = 0;
	const char *argv[4];

	if (!username)
		fail_username ();

	argv[argc++] = "usermod";
	argv[argc++] = param;
	argv[argc++] = username;
	argv[argc] = 0;

	execv (path, (char *const *) argv);
	failure (errno, "execv: %s", path);
}

static int
do_lock (void)
{
	lock_unlock ("-L");
}

static int
do_unlock (void)
{
	lock_unlock ("-U");
}

static int
do_status (void)
{
	struct passwd *pw;
	struct spwd *spw;
	const char *hash = 0, *p;

	if (!username)
		fail_username ();

	pw = getpwnam (username);
	endpwent ();
	if (!pw)
		failure (0, "user \"%s\" not found.", username);

	hash = pw->pw_passwd;

	if (!strcmp (hash, "x"))
	{
		spw = getspnam (username);
		endspent ();
		if (!spw)
			failure (errno,
				 "error reading user \"%s\" shadow entry",
				 username);

		hash = spw->sp_pwdp;
	} else if (!strcmp (hash, "*NP*"))
	{
		uid_t   old_uid;

		old_uid = geteuid ();
		seteuid (pw->pw_uid);
		spw = getspnam (username);
		endspent ();
		seteuid (old_uid);

		if (!spw)
			failure (errno,
				 "error reading user \"%s\" shadow entry",
				 username);

		hash = spw->sp_pwdp;
	}

	if (!hash || !hash[0])
	{
		puts ("Empty password.");
		return EXIT_SUCCESS;
	}

	if ('*' == hash[0] || !strcmp ("x", hash) || !strcmp ("!!", hash))
	{
		puts ("No Password set.");
		return EXIT_SUCCESS;
	}

	if ('!' == hash[0])
	{
		if (!hash[1])
		{
			puts ("Locked Empty password.");
			return EXIT_SUCCESS;
		}
		printf ("Locked password, ");
		p = hash + 1;
	} else
	{
		printf ("Password set, ");
		p = hash;
	}

	if (!strncmp (p, "$2a$", 4))
		puts ("blowfish encryption.");
	else if (!strncmp (p, "$1$", 3))
		puts ("MD5 encryption.");
	else if ('_' == p[0])
		puts ("BSDI encryption.");
	else if ('$' == p[0])
		puts ("unknown encryption.");
	else
		puts ("DES encryption.");

	return EXIT_SUCCESS;
}

static int
do_plain (void)
{
	const char *path = "/usr/bin/passwd";
	size_t  argc = 0;
	const char *argv[4];

	argv[argc++] = "passwd";

	if (is_keep)
		argv[argc++] = "-k";

	if (username)
		argv[argc++] = username;

	argv[argc] = 0;

	execv (path, (char *const *) argv);
	failure (errno, "execv: %s", path);
}

/* Parse a single option. */
static  error_t
parse_opt (int key, char *arg, struct argp_state *state)
{
	switch (key)
	{
		case 'd':
		case 'k':
		case 'l':
		case 'u':
		case 'S':
		case OPT_STDIN:
			if (do_fun)
			{
				fprintf (stderr,
					 "%s: options delete, keep-tokens, lock, unlock, status and stdin are mutually exclusive.\n",
					 program_invocation_short_name);
				argp_usage (state);
			}
	}

	switch (key)
	{
		case 'f':
			/* do nothing */
			break;
		case 'd':
			do_fun = do_delete;
			break;
		case 'k':
			is_keep = 1;
			do_fun = do_plain;
			break;
		case 'l':
			do_fun = do_lock;
			break;
		case 'u':
			do_fun = do_unlock;
			break;
		case 'S':
			do_fun = do_status;
			break;
		case OPT_STDIN:
			do_fun = do_stdin;
			break;
		case ARGP_KEY_ARG:
			if (state->arg_num == 0)
				/* First argument */
				username = arg;
			else
			{
				fprintf (stderr,
					 "%s: %s: unexpected argument.\n",
					 program_invocation_short_name, arg);
				argp_usage (state);
			}
			break;

		default:
			return ARGP_ERR_UNKNOWN;
	}
	return 0;
}

/* Our argp parser. */
static struct argp argp = {
	options, parse_opt, args_doc, doc, 0, 0, 0
};

int
main (int argc, char **__restrict argv)
{
	argp_parse (&argp, argc, argv, 0, 0, 0);
	if (!do_fun)
		do_fun = do_plain;

	return do_fun ();
}

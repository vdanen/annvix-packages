
/* 
 *
 * passwd.c
 *
 * Written for Linux-PAM by Andrew G. Morgan <morgan@linux.kernel.org>
 * Modified by Solar Designer <solar@owl.openwall.com>
 * Modified by Dmitry V. Levin <ldv@altlinux.org>
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <syslog.h>
#include <pwd.h>
#include <sys/stat.h>

#include <security/pam_misc.h>

static struct pam_conv conv = {
	misc_conv,
	NULL
};

#define	PASSWD_SERVICE	"passwd"
#define	PASSWD_FAIL_DELAY	2000000	/* usec delay on failure */

static void
fix_fds(void)
{
	struct stat st;

	if (fstat(STDOUT_FILENO, &st) < 0)
	{
		int     fd = open("/dev/null", O_WRONLY);

		if (fd < 0)
			exit(EXIT_FAILURE);
		if (fd != STDOUT_FILENO)
		{
			if (dup2(fd, STDOUT_FILENO) != STDOUT_FILENO)
				exit(EXIT_FAILURE);
			if (close(fd) < 0)
				exit(EXIT_FAILURE);
		}
	}

	if (fstat(STDERR_FILENO, &st) < 0)
	{
		int     fd = open("/dev/null", O_WRONLY);

		if (fd < 0)
			exit(EXIT_FAILURE);
		if (fd != STDERR_FILENO)
		{
			if (dup2(fd, STDERR_FILENO) != STDERR_FILENO)
				exit(EXIT_FAILURE);
			if (close(fd) < 0)
				exit(EXIT_FAILURE);
		}
	}
}

static void
__attribute__ ((noreturn, format(printf, 1, 2)))
show_usage(const char *fmt, ...)
{
	fprintf(stderr, "%s: ", program_invocation_short_name);

	va_list arg;

	va_start(arg, fmt);
	vfprintf(stderr, fmt, arg);
	va_end(arg);

	fprintf(stderr, ".\nTry `%s --help' for more information.\n",
		program_invocation_short_name);
	exit(EXIT_FAILURE);
}

static void
__attribute__ ((__noreturn__))
show_help(void)
{
	printf("Passwd is used to update a user's authentication token(s).\n\n"
	       "Usage: %s [options] [username]\n\n"
	       "Valid options and arguments are:\n"
	       "  -h or --help - print this help text and exit;\n"
	       "  -k           - keep non-expired authentication tokens;\n"
	       "  username     - update tokens for named user.\n",
	       program_invocation_short_name);
	exit(EXIT_SUCCESS);
}

static int
parse_pass_args(int ac, const char **av, const char **user)
{
	int     pam_flags = 0, i;

	*user = 0;

	if (ac < 1)
		show_usage("Insufficient arguments");

	for (i = 1; i < ac; ++i)
	{
		if (av[i][0] == '-')
		{
			/* options. */

			if (!strcmp(av[i], "-h") || !strcmp(av[i], "--help"))
				show_help();

			if (av[i][1] == 'k' && !av[i][2])
				pam_flags = PAM_CHANGE_EXPIRED_AUTHTOK;
			else
				show_usage("%s: Invalid option", av[i]);
		} else
		{
			if (*user)
				show_usage("%s: Too many arguments", av[i]);
			else
				*user = av[i];
		}
	}

	return pam_flags;
}

static const char *
get_user(const char *user)
{
	uid_t   uid = getuid();
	struct passwd *pwent;

	if (!user)
		user = getlogin();

	if (!user)
		pwent = getpwuid(uid);
	else
	{
		pwent = getpwnam(user);
		if (uid && (!pwent || pwent->pw_uid != uid))
		{
			fprintf(stderr,
				"passwd: only superuser can give different username.\n");
			exit(EXIT_FAILURE);
		}
	}

	endpwent();

	if (!pwent || !pwent->pw_name)
	{
		fprintf(stderr, "passwd: cannot retrieve username.\n");
		exit(EXIT_FAILURE);
	}

	user = strdup(pwent->pw_name);
	if (!user)
	{
		fprintf(stderr, "passwd: out of memory.\n");
		exit(EXIT_FAILURE);
	}

	return user;
}

static void
__attribute__ ((__noreturn__))
failure(pam_handle_t * pamh, int retval)
{
	if (pamh)
	{
		fprintf(stderr, "passwd: %s.\n", pam_strerror(pamh, retval));
		pam_end(pamh, retval);
	}

	exit(EXIT_FAILURE);
}

int
main(int ac, const char **av)
{
	const char *user = 0;
	int     pam_flags, retval;
	pam_handle_t *pamh = 0;

	fix_fds();

	pam_flags = parse_pass_args(ac, av, &user);

	user = get_user(user);

	setlinebuf(stdout);

	openlog(PASSWD_SERVICE, LOG_PID, LOG_AUTHPRIV);

	retval = pam_start(PASSWD_SERVICE, user, &conv, &pamh);
	if (PAM_SUCCESS != retval)
		failure(pamh, retval);

#ifdef HAVE_PAM_FAIL_DELAY
	retval = pam_fail_delay(pamh, PASSWD_FAIL_DELAY);
	if (PAM_SUCCESS != retval)
	{
		fprintf(stderr, "passwd: unable to set failure delay.\n");
		pam_end(pamh, retval);
		exit(EXIT_FAILURE);
	}
#endif /* HAVE_PAM_FAIL_DELAY */

	/*
	 * The user is authenticated by the passwd module;
	 * change the password(s) too.
	 */

	if (!getuid())
		fprintf(stderr,
			"passwd: updating %s authentication tokens for user %s.\n",
			pam_flags ? "expired" : "all", user);

	retval = pam_chauthtok(pamh, pam_flags);
	if (PAM_SUCCESS != retval)
		failure(pamh, retval);

	/* All done. */

	retval = pam_end(pamh, PAM_SUCCESS);
	if (PAM_SUCCESS != retval)
		failure(pamh, retval);

	/* Quit gracefully. */

	fprintf(stderr,
		"passwd: %s authentication tokens updated successfully.\n",
		pam_flags ? "expired" : "all");

	return PAM_SUCCESS;
}

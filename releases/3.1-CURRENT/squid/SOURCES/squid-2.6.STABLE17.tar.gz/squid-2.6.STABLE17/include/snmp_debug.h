/*
 * $Id: snmp_debug.h,v 1.12 2005/05/17 16:56:35 hno Exp $
 */

#ifndef SQUID_SNMP_DEBUG_H
#define SQUID_SNMP_DEBUG_H

extern void 
snmplib_debug(int, const char *,...) PRINTF_FORMAT_ARG2;

#endif /* SQUID_SNMP_DEBUG_H */

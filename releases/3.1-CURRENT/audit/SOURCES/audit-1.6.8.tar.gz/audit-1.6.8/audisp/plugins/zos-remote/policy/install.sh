/usr/sbin/semodule -i audispd-zos-remote.pp

/sbin/restorecon -F -v /sbin/audispd-zos-remote


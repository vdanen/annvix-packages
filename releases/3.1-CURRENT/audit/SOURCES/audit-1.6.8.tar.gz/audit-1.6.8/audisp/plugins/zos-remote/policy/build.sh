
#!/bin/sh
make -f /usr/share/selinux/devel/Makefile
